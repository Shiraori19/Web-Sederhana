<?php
$pageTitle = 'Supplier';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['action'] ?? '';
    if ($act === 'add') {
        $n=sanitize($conn,$_POST['nama']); $k=sanitize($conn,$_POST['kontak']); $e=sanitize($conn,$_POST['email']);
        $a=sanitize($conn,$_POST['alamat']); $kt=sanitize($conn,$_POST['kota']);
        $conn->query("INSERT INTO supplier (nama,kontak,email,alamat,kota) VALUES ('$n','$k','$e','$a','$kt')");
        setFlash('success','Supplier berhasil ditambahkan!');
    } elseif ($act === 'edit') {
        $id=(int)$_POST['id']; $n=sanitize($conn,$_POST['nama']); $k=sanitize($conn,$_POST['kontak']);
        $e=sanitize($conn,$_POST['email']); $a=sanitize($conn,$_POST['alamat']); $kt=sanitize($conn,$_POST['kota']);
        $st=sanitize($conn,$_POST['status']);
        $conn->query("UPDATE supplier SET nama='$n',kontak='$k',email='$e',alamat='$a',kota='$kt',status='$st' WHERE id=$id");
        setFlash('success','Supplier diupdate!');
    } elseif ($act === 'delete') {
        $conn->query("DELETE FROM supplier WHERE id=".(int)$_POST['id']);
        setFlash('success','Supplier dihapus!');
    }
    header('Location: index.php'); exit;
}

$suppliers = [];
$r = $conn->query("SELECT s.*, (SELECT COUNT(*) FROM purchase_order WHERE supplier_id=s.id) as po_count FROM supplier s ORDER BY s.nama");
if ($r) while($row = $r->fetch_assoc()) $suppliers[] = $row;

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div><h1><i class="bi bi-building me-2"></i>Supplier</h1><p>Kelola data supplier</p></div>
    <button class="btn btn-primary-glass" data-bs-toggle="modal" data-bs-target="#addModal"><i class="bi bi-plus-lg me-2"></i>Tambah</button>
</div>

<div class="card-glass">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead><tr><th>Nama</th><th>Kontak</th><th>Email</th><th>Kota</th><th>Status</th><th>PO</th><th>Aksi</th></tr></thead>
                <tbody>
                <?php foreach($suppliers as $s): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($s['nama']) ?></strong></td>
                    <td><?= $s['kontak'] ?></td>
                    <td style="color:var(--text-muted)"><?= $s['email'] ?></td>
                    <td><?= $s['kota'] ?></td>
                    <td><span class="badge-status <?= $s['status']=='aktif'?'badge-success':'badge-danger' ?>"><?= ucfirst($s['status']) ?></span></td>
                    <td><span class="badge-status badge-info"><?= $s['po_count'] ?></span></td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="../procurement/tambah.php?supplier_id=<?= $s['id'] ?>" class="btn-sm-icon" title="Buat PO"><i class="bi bi-clipboard-plus"></i></a>
                            <button class="btn-sm-icon" onclick='editSup(<?= json_encode($s) ?>)' title="Edit"><i class="bi bi-pencil"></i></button>
                            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="btn-sm-icon danger"><i class="bi bi-trash"></i></button></form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($suppliers)): ?><tr><td colspan="7" class="empty-state-dash">Belum ada supplier</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal"><div class="modal-dialog"><div class="modal-content modal-content-glass">
<div class="modal-header"><h5 class="modal-title">Tambah Supplier</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="modal-body">
    <div class="mb-3"><label class="form-label-glass">Nama *</label><input type="text" name="nama" class="form-control form-control-glass" required></div>
    <div class="row g-2 mb-3"><div class="col-6"><label class="form-label-glass">Kontak</label><input type="text" name="kontak" class="form-control form-control-glass"></div><div class="col-6"><label class="form-label-glass">Email</label><input type="email" name="email" class="form-control form-control-glass"></div></div>
    <div class="mb-3"><label class="form-label-glass">Alamat</label><textarea name="alamat" class="form-control form-control-glass" rows="2"></textarea></div>
    <div class="mb-3"><label class="form-label-glass">Kota</label><input type="text" name="kota" class="form-control form-control-glass"></div>
</div>
<div class="modal-footer"><button type="button" class="btn btn-outline-glass" data-bs-dismiss="modal">Batal</button><button class="btn btn-primary-glass">Simpan</button></div>
</form></div></div></div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal"><div class="modal-dialog"><div class="modal-content modal-content-glass">
<div class="modal-header"><h5 class="modal-title">Edit Supplier</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<form method="POST"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" id="esId">
<div class="modal-body">
    <div class="mb-3"><label class="form-label-glass">Nama *</label><input type="text" name="nama" id="esNama" class="form-control form-control-glass" required></div>
    <div class="row g-2 mb-3"><div class="col-6"><label class="form-label-glass">Kontak</label><input type="text" name="kontak" id="esKontak" class="form-control form-control-glass"></div><div class="col-6"><label class="form-label-glass">Email</label><input type="email" name="email" id="esEmail" class="form-control form-control-glass"></div></div>
    <div class="mb-3"><label class="form-label-glass">Alamat</label><textarea name="alamat" id="esAlamat" class="form-control form-control-glass" rows="2"></textarea></div>
    <div class="row g-2 mb-3"><div class="col-6"><label class="form-label-glass">Kota</label><input type="text" name="kota" id="esKota" class="form-control form-control-glass"></div><div class="col-6"><label class="form-label-glass">Status</label><select name="status" id="esStatus" class="form-select form-select-glass"><option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option></select></div></div>
</div>
<div class="modal-footer"><button type="button" class="btn btn-outline-glass" data-bs-dismiss="modal">Batal</button><button class="btn btn-primary-glass">Update</button></div>
</form></div></div></div>

<script>
function editSup(d) {
    document.getElementById('esId').value=d.id; document.getElementById('esNama').value=d.nama;
    document.getElementById('esKontak').value=d.kontak||''; document.getElementById('esEmail').value=d.email||'';
    document.getElementById('esAlamat').value=d.alamat||''; document.getElementById('esKota').value=d.kota||'';
    document.getElementById('esStatus').value=d.status;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
