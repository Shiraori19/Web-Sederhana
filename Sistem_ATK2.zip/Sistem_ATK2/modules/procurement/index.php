<?php
$pageTitle = 'Purchase Order';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin', 'gudang']);

$isGudang = ($_SESSION['user_role'] === 'gudang');

// Handle status change
if (isset($_GET['receive'])) {
    requireRole(['admin', 'gudang']);
    $poId = (int)$_GET['receive'];
    // Validasi: PO harus berstatus 'dikirim' sebelum bisa diterima
    $poCek = $conn->query("SELECT status FROM purchase_order WHERE id=$poId")->fetch_assoc();
    if (!$poCek || $poCek['status'] !== 'dikirim') {
        setFlash('error', 'PO hanya bisa dikonfirmasi diterima jika sudah berstatus Dikirim. Pastikan admin sudah menandai PO sebagai Dikirim terlebih dahulu.');
        header('Location: index.php'); exit;
    }
    $conn->query("UPDATE purchase_order SET status='diterima', tanggal_diterima='".date('Y-m-d')."' WHERE id=$poId");
    $items = $conn->query("SELECT produk_id,jumlah,harga FROM detail_po WHERE po_id=$poId");
    while ($item = $items->fetch_assoc()) {
        $conn->query("UPDATE produk SET stok=stok+{$item['jumlah']}, harga_beli={$item['harga']} WHERE id={$item['produk_id']}");
        $conn->query("INSERT INTO stok_masuk (produk_id,jumlah,harga_beli,tanggal,keterangan,user_id) VALUES ({$item['produk_id']},{$item['jumlah']},{$item['harga']},'".date('Y-m-d')."','PO Diterima: #$poId',{$_SESSION['user_id']})");
    }
    setFlash('success','Barang diterima! Stok telah diperbarui secara otomatis.');
    header('Location: index.php'); exit;
}

if (!$isGudang) {
    if (isset($_GET['send'])) {
        $conn->query("UPDATE purchase_order SET status='dikirim' WHERE id=".(int)$_GET['send']);
        setFlash('success','Status PO diubah ke Dikirim.');
        header('Location: index.php'); exit;
    }
    if (isset($_GET['cancel'])) {
        $conn->query("UPDATE purchase_order SET status='dibatalkan' WHERE id=".(int)$_GET['cancel']);
        setFlash('success','PO dibatalkan.');
        header('Location: index.php'); exit;
    }
}

$pos = [];
$r = $conn->query("SELECT po.*, s.nama as supplier_nama, u.nama as user_nama FROM purchase_order po LEFT JOIN supplier s ON po.supplier_id=s.id LEFT JOIN users u ON po.user_id=u.id ORDER BY po.id DESC");
if ($r) while($row = $r->fetch_assoc()) $pos[] = $row;

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';

$statusBadge = ['draft'=>'badge-secondary','dikirim'=>'badge-warning','diterima'=>'badge-success','dibatalkan'=>'badge-danger'];

$waitingCount = 0;
foreach ($pos as $po) {
    if (in_array($po['status'], ['draft', 'dikirim'])) $waitingCount++;
}
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-<?= $isGudang ? 'truck' : 'clipboard-check' ?> me-2"></i>
            <?= $isGudang ? 'Penerimaan Barang' : 'Purchase Order' ?>
        </h1>
        <p><?= $isGudang ? 'Konfirmasi barang yang telah tiba dari supplier' : 'Kelola purchase order ke supplier' ?></p>
    </div>
    <?php if (!$isGudang): ?>
    <a href="tambah.php" class="btn btn-primary-glass"><i class="bi bi-plus-lg me-2"></i>Buat PO Baru</a>
    <?php endif; ?>
</div>

<?php if ($isGudang && $waitingCount > 0): ?>
<div class="card-glass mb-4" style="border-color:rgba(245,158,11,0.3)">
    <div class="card-body py-3 d-flex align-items-center gap-3">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(245,158,11,0.15);display:flex;align-items:center;justify-content:center;color:var(--warning);font-size:20px;flex-shrink:0">
            <i class="bi bi-exclamation-triangle-fill"></i>
        </div>
        <div>
            <div style="font-weight:700;color:var(--warning)"><?= $waitingCount ?> PO menunggu konfirmasi penerimaan</div>
            <div style="font-size:13px;color:var(--text-muted)">Klik tombol <i class="bi bi-check-circle"></i> pada PO dengan status <strong>Dikirim</strong> setelah barang tiba.</div>
        </div>
    </div>
</div>
<?php elseif ($isGudang): ?>
<div class="card-glass mb-4" style="border-color:rgba(16,185,129,0.3)">
    <div class="card-body py-3 d-flex align-items-center gap-3">
        <div style="width:44px;height:44px;border-radius:12px;background:rgba(16,185,129,0.12);display:flex;align-items:center;justify-content:center;color:var(--success);font-size:20px;flex-shrink:0">
            <i class="bi bi-check-circle-fill"></i>
        </div>
        <div>
            <div style="font-weight:700;color:var(--success)">Semua PO sudah diterima</div>
            <div style="font-size:13px;color:var(--text-muted)">Tidak ada barang yang menunggu konfirmasi penerimaan saat ini.</div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card-glass">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead><tr>
                    <th>No PO</th>
                    <th>Tanggal</th>
                    <th>Supplier</th>
                    <th>Total</th>
                    <th>Status</th>
                    <?php if (!$isGudang): ?><th>Dibuat Oleh</th><?php endif; ?>
                    <th>Aksi</th>
                </tr></thead>
                <tbody>
                <?php foreach($pos as $po): ?>
                <tr>
                    <td>
                        <a href="detail.php?id=<?= $po['id'] ?>" style="font-weight:700;color:var(--accent);text-decoration:none" title="Lihat Detail PO">
                            <?= htmlspecialchars($po['no_po']) ?>
                            <i class="bi bi-box-arrow-up-right" style="font-size:10px;opacity:0.6;margin-left:4px"></i>
                        </a>
                    </td>
                    <td><?= date('d/m/Y', strtotime($po['tanggal'])) ?></td>
                    <td><?= htmlspecialchars($po['supplier_nama'] ?? '-') ?></td>
                    <td><?= formatRupiah($po['total']) ?></td>
                    <td><span class="badge-status <?= $statusBadge[$po['status']] ?>"><?= ucfirst($po['status']) ?></span></td>
                    <?php if (!$isGudang): ?>
                    <td style="color:var(--text-muted);font-size:12px"><?= htmlspecialchars($po['user_nama'] ?? '-') ?></td>
                    <?php endif; ?>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="detail.php?id=<?= $po['id'] ?>" class="btn-sm-icon" title="Lihat Detail">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if ($isGudang): ?>
                                <?php if ($po['status'] === 'dikirim'): ?>
                                <button type="button" class="btn-sm-icon" title="Konfirmasi Barang Tiba"
                                    onclick="openConfirm('receive', <?= $po['id'] ?>, '<?= addslashes($po['no_po']) ?>', 'Konfirmasi barang PO <strong><?= addslashes($po['no_po']) ?></strong> sudah tiba?<br><small style=\'color:var(--text-muted)\'>Stok produk akan otomatis bertambah sesuai isi PO.</small>', 'var(--success)', 'bi-check-circle')">
                                    <i class="bi bi-check-circle"></i>
                                </button>
                                <?php elseif ($po['status'] === 'draft'): ?>
                                <span style="color:var(--text-muted);font-size:12px;padding:4px 8px">Menunggu pengiriman</span>
                                <?php elseif ($po['status'] === 'diterima'): ?>
                                <span style="color:var(--success);font-size:12px;padding:4px 8px"><i class="bi bi-check2-all me-1"></i>Sudah diterima</span>
                                <?php else: ?>
                                <span style="color:var(--text-muted);font-size:12px;padding:4px 8px">—</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($po['status']==='draft'): ?>
                                <button type="button" class="btn-sm-icon" title="Kirim ke Supplier"
                                    onclick="openConfirm('send', <?= $po['id'] ?>, '<?= addslashes($po['no_po']) ?>', 'Kirim PO <strong><?= addslashes($po['no_po']) ?></strong> ke supplier?<br><small style=\'color:var(--text-muted)\'>Status akan berubah menjadi <em>Dikirim</em>.</small>', 'var(--accent)', 'bi-send')">
                                    <i class="bi bi-send"></i>
                                </button>
                                <?php endif; ?>
                                <?php if($po['status']==='dikirim'): ?>
                                <button type="button" class="btn-sm-icon" title="Konfirmasi Barang Tiba"
                                    onclick="openConfirm('receive', <?= $po['id'] ?>, '<?= addslashes($po['no_po']) ?>', 'Konfirmasi barang PO <strong><?= addslashes($po['no_po']) ?></strong> sudah tiba?<br><small style=\'color:var(--text-muted)\'>Stok akan otomatis ditambahkan.</small>', 'var(--success)', 'bi-check-circle')">
                                    <i class="bi bi-check-circle"></i>
                                </button>
                                <?php endif; ?>
                                <?php if(in_array($po['status'],['draft','dikirim'])): ?>
                                <button type="button" class="btn-sm-icon danger" title="Batalkan"
                                    onclick="openConfirm('cancel', <?= $po['id'] ?>, '<?= addslashes($po['no_po']) ?>', 'Batalkan PO <strong><?= addslashes($po['no_po']) ?></strong>?<br><small style=\'color:var(--text-muted)\'>Tindakan ini tidak bisa dibatalkan.</small>', 'var(--danger)', 'bi-x-circle')">
                                    <i class="bi bi-x-circle"></i>
                                </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($pos)): ?><tr><td colspan="7" class="empty-state-dash">Belum ada Purchase Order</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Custom Confirm Modal -->
<div id="confirmOverlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);z-index:9998;align-items:center;justify-content:center;">
    <div style="background:var(--dark-2);border:1px solid var(--border);border-radius:var(--radius);padding:32px;max-width:420px;width:90%;animation:slideInRight 0.25s ease;">
        <div id="confirmIcon" style="width:56px;height:56px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:26px;margin:0 auto 20px;"></div>
        <div id="confirmTitle" style="font-size:17px;font-weight:700;color:var(--text-bright);text-align:center;margin-bottom:10px;"></div>
        <div id="confirmBody" style="font-size:13px;color:var(--text-muted);text-align:center;margin-bottom:28px;line-height:1.6;"></div>
        <div style="display:flex;gap:10px;justify-content:center;">
            <button type="button" onclick="closeConfirm()" class="btn btn-outline-glass" style="min-width:100px;">Batal</button>
            <a id="confirmBtn" href="#" class="btn btn-primary-glass" style="min-width:100px;text-align:center;">Ya, Lanjutkan</a>
        </div>
    </div>
</div>

<script>
function openConfirm(action, poId, noPoLabel, bodyHtml, color, icon) {
    var overlay = document.getElementById('confirmOverlay');
    document.getElementById('confirmTitle').textContent = noPoLabel;
    document.getElementById('confirmBody').innerHTML = bodyHtml;
    document.getElementById('confirmBtn').href = '?'+action+'='+poId;

    var iconEl = document.getElementById('confirmIcon');
    iconEl.style.background = 'rgba('+colorToRgb(color)+',0.12)';
    iconEl.style.color = color;
    iconEl.innerHTML = '<i class="bi '+icon+'"></i>';

    overlay.style.display = 'flex';
    // Close on overlay click
    overlay.onclick = function(e) { if (e.target === overlay) closeConfirm(); };
}

function closeConfirm() {
    document.getElementById('confirmOverlay').style.display = 'none';
}

// Keyboard close
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeConfirm();
});

function colorToRgb(cssVar) {
    // Simple fallback for CSS var colors
    var map = {
        'var(--success)': '16,185,129',
        'var(--danger)': '239,68,68',
        'var(--warning)': '245,158,11',
        'var(--accent)': '6,182,212',
        'var(--primary)': '99,102,241',
    };
    return map[cssVar] || '99,102,241';
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
