<?php
$pageTitle = 'Detail Purchase Order';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin', 'gudang']);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

// Ambil data PO header
$po = $conn->query("
    SELECT po.*, s.nama as supplier_nama, s.kontak as supplier_kontak, s.email as supplier_email,
           s.alamat as supplier_alamat, u.nama as user_nama
    FROM purchase_order po
    LEFT JOIN supplier s ON po.supplier_id = s.id
    LEFT JOIN users u ON po.user_id = u.id
    WHERE po.id = $id
")->fetch_assoc();

if (!$po) { setFlash('error', 'PO tidak ditemukan.'); header('Location: index.php'); exit; }

// Ambil detail item PO
$items = [];
$r = $conn->query("
    SELECT dp.*, p.nama as produk_nama, p.kode as produk_kode, p.satuan, p.stok as stok_sekarang
    FROM detail_po dp
    JOIN produk p ON dp.produk_id = p.id
    WHERE dp.po_id = $id
    ORDER BY p.nama
");
if ($r) while ($row = $r->fetch_assoc()) $items[] = $row;

// Ambil riwayat stok masuk yang terkait PO ini
$riwayat = [];
$r = $conn->query("
    SELECT sm.*, p.nama as produk_nama, p.kode as produk_kode, u.nama as user_nama
    FROM stok_masuk sm
    JOIN produk p ON sm.produk_id = p.id
    LEFT JOIN users u ON sm.user_id = u.id
    WHERE sm.keterangan LIKE '%#$id%'
    ORDER BY sm.created_at DESC
");
if ($r) while ($row = $r->fetch_assoc()) $riwayat[] = $row;

$statusBadge = ['draft'=>'badge-secondary','dikirim'=>'badge-warning','diterima'=>'badge-success','dibatalkan'=>'badge-danger'];
$statusLabel = ['draft'=>'Draft','dikirim'=>'Dikirim ke Supplier','diterima'=>'Diterima','dibatalkan'=>'Dibatalkan'];

$isGudang = ($_SESSION['user_role'] === 'gudang');

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-clipboard-check me-2"></i>Detail Purchase Order</h1>
        <p><code style="color:var(--accent);font-size:16px"><?= htmlspecialchars($po['no_po']) ?></code></p>
    </div>
    <div class="d-flex gap-2">
        <?php if (!$isGudang && $po['status'] === 'draft'): ?>
        <a href="index.php?send=<?= $po['id'] ?>" class="btn btn-outline-glass"
           onclick="return confirm('Kirim PO ini ke supplier?')">
            <i class="bi bi-send me-2"></i>Kirim ke Supplier
        </a>
        <?php endif; ?>
        <?php if ($po['status'] === 'dikirim'): ?>
        <a href="index.php?receive=<?= $po['id'] ?>" class="btn btn-primary-glass"
           onclick="return confirm('Konfirmasi barang PO ini sudah tiba di gudang?')">
            <i class="bi bi-check-circle me-2"></i>Konfirmasi Diterima
        </a>
        <?php endif; ?>
        <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
    </div>
</div>

<!-- Status Timeline -->
<div class="card-glass mb-4">
    <div class="card-body py-3">
        <div style="display:flex;align-items:center;gap:0;flex-wrap:wrap;">
            <?php
            $steps = [
                'draft'      => ['icon'=>'bi-clipboard-plus',  'label'=>'Draft Dibuat',       'date'=>$po['tanggal']],
                'dikirim'    => ['icon'=>'bi-send',             'label'=>'Dikirim ke Supplier', 'date'=>null],
                'diterima'   => ['icon'=>'bi-check-circle',    'label'=>'Barang Diterima',     'date'=>$po['tanggal_diterima']],
            ];
            $statusOrder = ['draft','dikirim','diterima'];
            $currentIdx  = array_search($po['status'], $statusOrder);
            if ($po['status'] === 'dibatalkan') $currentIdx = -1;
            foreach ($statusOrder as $i => $st):
                $done    = ($i <= $currentIdx);
                $active  = ($i === $currentIdx);
                $clr     = $done ? ($active && $st==='diterima' ? 'var(--success)' : ($active ? 'var(--accent)' : 'var(--success)')) : 'var(--text-muted)';
            ?>
            <div style="display:flex;align-items:center;flex:1;min-width:120px;">
                <div style="text-align:center;flex:1;">
                    <div style="width:40px;height:40px;border-radius:50%;background:<?= $done?'rgba('.($st==='diterima'&&$done?'16,185,129':'6,182,212').',0.15)':'var(--dark-3)' ?>;border:2px solid <?= $done?$clr:'var(--border)' ?>;display:flex;align-items:center;justify-content:center;margin:0 auto 6px;color:<?= $clr ?>;font-size:16px;transition:all .3s;">
                        <i class="bi <?= $steps[$st]['icon'] ?>"></i>
                    </div>
                    <div style="font-size:11px;font-weight:600;color:<?= $done?'var(--text-bright)':'var(--text-muted)' ?>"><?= $steps[$st]['label'] ?></div>
                    <?php if ($steps[$st]['date']): ?>
                    <div style="font-size:10px;color:var(--text-muted)"><?= date('d/m/Y', strtotime($steps[$st]['date'])) ?></div>
                    <?php endif; ?>
                </div>
                <?php if ($i < count($statusOrder)-1): ?>
                <div style="flex:1;height:2px;background:<?= $i < $currentIdx ? 'var(--success)' : 'var(--dark-3)' ?>;margin:0 4px;margin-bottom:18px;"></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php if ($po['status'] === 'dibatalkan'): ?>
            <div style="margin-left:12px;"><span class="badge-status badge-danger"><i class="bi bi-x-circle me-1"></i>Dibatalkan</span></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Info PO -->
    <div class="col-md-6">
        <div class="card-glass h-100">
            <div class="card-header"><i class="bi bi-info-circle me-2"></i>Informasi PO</div>
            <div class="card-body">
                <table style="width:100%;border-collapse:collapse;">
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);width:140px;font-size:13px">No. PO</td>
                        <td style="padding:8px 0;font-weight:700;color:var(--accent)"><?= htmlspecialchars($po['no_po']) ?></td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);font-size:13px">Status</td>
                        <td style="padding:8px 0"><span class="badge-status <?= $statusBadge[$po['status']] ?>"><?= $statusLabel[$po['status']] ?></span></td>
                    </tr>
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);font-size:13px">Tanggal PO</td>
                        <td style="padding:8px 0;color:var(--text-bright)"><?= date('d F Y', strtotime($po['tanggal'])) ?></td>
                    </tr>
                    <?php if ($po['tanggal_diterima']): ?>
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);font-size:13px">Tanggal Terima</td>
                        <td style="padding:8px 0;color:var(--success);font-weight:600"><?= date('d F Y', strtotime($po['tanggal_diterima'])) ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);font-size:13px">Dibuat Oleh</td>
                        <td style="padding:8px 0;color:var(--text-bright)"><?= htmlspecialchars($po['user_nama'] ?? '-') ?></td>
                    </tr>
                    <?php if ($po['catatan']): ?>
                    <tr>
                        <td style="padding:8px 0;color:var(--text-muted);font-size:13px;vertical-align:top">Catatan</td>
                        <td style="padding:8px 0;color:var(--text-bright)"><?= nl2br(htmlspecialchars($po['catatan'])) ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr style="border-top:1px solid var(--border)">
                        <td style="padding:12px 0 4px;color:var(--text-muted);font-size:13px">Total Nilai PO</td>
                        <td style="padding:12px 0 4px;font-weight:800;font-size:18px;color:var(--accent)"><?= formatRupiah($po['total']) ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <!-- Info Supplier -->
    <div class="col-md-6">
        <div class="card-glass h-100">
            <div class="card-header"><i class="bi bi-building me-2"></i>Informasi Supplier</div>
            <div class="card-body">
                <div style="font-size:17px;font-weight:700;color:var(--text-bright);margin-bottom:16px">
                    <i class="bi bi-shop me-2" style="color:var(--accent)"></i><?= htmlspecialchars($po['supplier_nama'] ?? '-') ?>
                </div>
                <?php if ($po['supplier_kontak']): ?>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:var(--text-muted);font-size:13px">
                    <i class="bi bi-telephone" style="color:var(--success)"></i>
                    <span><?= htmlspecialchars($po['supplier_kontak']) ?></span>
                </div>
                <?php endif; ?>
                <?php if ($po['supplier_email']): ?>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;color:var(--text-muted);font-size:13px">
                    <i class="bi bi-envelope" style="color:var(--warning)"></i>
                    <span><?= htmlspecialchars($po['supplier_email']) ?></span>
                </div>
                <?php endif; ?>
                <?php if ($po['supplier_alamat']): ?>
                <div style="display:flex;align-items:flex-start;gap:10px;color:var(--text-muted);font-size:13px">
                    <i class="bi bi-geo-alt" style="color:var(--danger);margin-top:2px"></i>
                    <span><?= nl2br(htmlspecialchars($po['supplier_alamat'])) ?></span>
                </div>
                <?php endif; ?>
                <?php if (!$po['supplier_kontak'] && !$po['supplier_email'] && !$po['supplier_alamat']): ?>
                <p style="color:var(--text-muted);font-size:13px">Tidak ada informasi kontak supplier.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Daftar Item Barang -->
<div class="card-glass mb-4">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span><i class="bi bi-list-ul me-2"></i>Daftar Item Barang</span>
        <span style="font-size:12px;color:var(--text-muted)"><?= count($items) ?> item</span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Kode</th>
                        <th>Nama Produk</th>
                        <th style="text-align:center">Jumlah Pesan</th>
                        <th style="text-align:right">Harga Beli/unit</th>
                        <th style="text-align:right">Subtotal</th>
                        <th style="text-align:center">Stok Saat Ini</th>
                        <?php if ($po['status'] === 'diterima'): ?>
                        <th style="text-align:center">Status Terima</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($items as $i => $item): ?>
                <tr>
                    <td style="color:var(--text-muted);font-size:12px"><?= $i+1 ?></td>
                    <td><code style="color:var(--accent)"><?= htmlspecialchars($item['produk_kode']) ?></code></td>
                    <td><strong style="color:var(--text-bright)"><?= htmlspecialchars($item['produk_nama']) ?></strong></td>
                    <td style="text-align:center;font-weight:700"><?= number_format($item['jumlah']) ?> <span style="font-size:11px;color:var(--text-muted)"><?= $item['satuan'] ?></span></td>
                    <td style="text-align:right"><?= formatRupiah($item['harga']) ?></td>
                    <td style="text-align:right;font-weight:600;color:var(--accent)"><?= formatRupiah($item['subtotal']) ?></td>
                    <td style="text-align:center">
                        <?php
                        $stokClr = $item['stok_sekarang'] <= 0 ? 'var(--danger)' : ($item['stok_sekarang'] <= 10 ? 'var(--warning)' : 'var(--success)');
                        ?>
                        <strong style="color:<?= $stokClr ?>"><?= $item['stok_sekarang'] ?></strong>
                        <span style="font-size:11px;color:var(--text-muted)"><?= $item['satuan'] ?></span>
                    </td>
                    <?php if ($po['status'] === 'diterima'): ?>
                    <td style="text-align:center"><span style="color:var(--success);font-size:12px"><i class="bi bi-check2-circle me-1"></i>Diterima</span></td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($items)): ?>
                <tr><td colspan="8" class="empty-state-dash">Tidak ada item dalam PO ini</td></tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5" style="text-align:right;font-weight:700;color:var(--text-bright);padding:14px 16px">TOTAL</td>
                        <td style="text-align:right;font-weight:800;color:var(--accent);font-size:16px;padding:14px 16px"><?= formatRupiah($po['total']) ?></td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- Riwayat Penerimaan -->
<?php if (!empty($riwayat)): ?>
<div class="card-glass">
    <div class="card-header"><i class="bi bi-clock-history me-2"></i>Riwayat Penerimaan Barang</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead>
                    <tr>
                        <th>Tanggal Terima</th>
                        <th>Kode</th>
                        <th>Produk</th>
                        <th style="text-align:center">Jumlah Diterima</th>
                        <th style="text-align:right">Harga Beli</th>
                        <th>Dikonfirmasi Oleh</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($riwayat as $r): ?>
                <tr>
                    <td>
                        <div style="font-weight:600;color:var(--text-bright)"><?= date('d/m/Y', strtotime($r['tanggal'])) ?></div>
                        <div style="font-size:11px;color:var(--text-muted)"><?= date('H:i', strtotime($r['created_at'])) ?></div>
                    </td>
                    <td><code style="color:var(--accent)"><?= htmlspecialchars($r['produk_kode']) ?></code></td>
                    <td><strong><?= htmlspecialchars($r['produk_nama']) ?></strong></td>
                    <td style="text-align:center">
                        <span style="background:rgba(16,185,129,0.12);color:var(--success);padding:4px 12px;border-radius:20px;font-weight:700">
                            +<?= number_format($r['jumlah']) ?>
                        </span>
                    </td>
                    <td style="text-align:right"><?= formatRupiah($r['harga_beli']) ?></td>
                    <td style="color:var(--text-muted);font-size:13px"><i class="bi bi-person me-1"></i><?= htmlspecialchars($r['user_nama'] ?? '-') ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php elseif ($po['status'] === 'diterima'): ?>
<div class="card-glass">
    <div class="card-body" style="text-align:center;padding:32px;color:var(--text-muted)">
        <i class="bi bi-info-circle me-2"></i>Data riwayat penerimaan tidak tersedia untuk PO ini.
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
