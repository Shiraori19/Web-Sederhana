<?php
$pageTitle = 'Buat Purchase Order';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin']);

$suppliers = []; $r = $conn->query("SELECT * FROM supplier WHERE status='aktif' ORDER BY nama");
if ($r) while($row = $r->fetch_assoc()) $suppliers[] = $row;

$products = []; $r = $conn->query("SELECT id,kode,nama,stok,stok_minimum,harga_beli FROM produk WHERE is_active=1 ORDER BY nama");
if ($r) while($row = $r->fetch_assoc()) $products[] = $row;

// Low stock products for auto-suggest
$lowStock = []; $r = $conn->query("SELECT id,kode,nama,stok,stok_minimum,harga_beli FROM produk WHERE is_active=1 AND stok<=stok_minimum ORDER BY stok ASC");
if ($r) while($row = $r->fetch_assoc()) $lowStock[] = $row;

$preSupplier = (int)($_GET['supplier_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $supplier_id = (int)$_POST['supplier_id'];
    $catatan = sanitize($conn, $_POST['catatan']);
    $items = json_decode($_POST['items_data'], true);

    if (empty($items)) { setFlash('error','Belum ada item!'); header('Location: tambah.php'); exit; }

    $noPo = generatePO();
    $total = 0;
    foreach ($items as $it) $total += $it['harga'] * $it['jumlah'];

    $uid = $_SESSION['user_id'];
    $conn->query("INSERT INTO purchase_order (no_po,supplier_id,total,catatan,tanggal,user_id) VALUES ('$noPo',$supplier_id,$total,'$catatan','".date('Y-m-d')."',$uid)");
    $poId = $conn->insert_id;

    foreach ($items as $it) {
        $pid = (int)$it['id'];
        $qty = (int)$it['jumlah'];
        $hrg = (float)$it['harga'];
        $sub = $hrg * $qty;
        $conn->query("INSERT INTO detail_po (po_id,produk_id,jumlah,harga,subtotal) VALUES ($poId,$pid,$qty,$hrg,$sub)");
    }

    setFlash('success',"PO $noPo berhasil dibuat! Total: " . formatRupiah($total));
    header('Location: index.php'); exit;
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div><h1><i class="bi bi-clipboard-plus me-2"></i>Buat Purchase Order</h1></div>
    <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div>

<?php if(!empty($lowStock)): ?>
<div class="card-glass mb-4" style="border-color:rgba(245,158,11,0.3)">
    <div class="card-header" style="color:var(--warning)"><i class="bi bi-exclamation-triangle me-2"></i>Produk Stok Menipis — Klik untuk tambahkan ke PO</div>
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <?php foreach($lowStock as $ls): ?>
            <button type="button" class="btn btn-outline-glass btn-sm" onclick="addLowStockItem(<?= htmlspecialchars(json_encode($ls)) ?>)">
                <?= htmlspecialchars($ls['nama']) ?> <span class="badge-status badge-danger ms-1">Stok: <?= $ls['stok'] ?></span>
            </button>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<form method="POST" id="poForm">
    <input type="hidden" name="items_data" id="itemsData">
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card-glass"><div class="card-body">
                <label class="form-label-glass">Supplier *</label>
                <select name="supplier_id" class="form-select form-select-glass" required>
                    <option value="">-- Pilih Supplier --</option>
                    <?php foreach($suppliers as $s): ?>
                    <option value="<?= $s['id'] ?>" <?= $preSupplier==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['nama']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div></div>
        </div>
        <div class="col-md-6">
            <div class="card-glass"><div class="card-body">
                <label class="form-label-glass">Catatan (Opsional)</label>
                <input type="text" name="catatan" class="form-control form-control-glass" placeholder="Catatan untuk PO ini...">
            </div></div>
        </div>
    </div>

    <!-- Add Item -->
    <div class="card-glass mb-3">
        <div class="card-header">Tambah Item</div>
        <div class="card-body">
            <div class="row g-2 align-items-end">
                <div class="col-md-5">
                    <label class="form-label-glass">Produk</label>
                    <select id="selProduk" class="form-select form-select-glass">
                        <option value="">-- Pilih --</option>
                        <?php foreach($products as $p): ?>
                        <option value="<?= $p['id'] ?>" data-price="<?= $p['harga_beli'] ?>" data-name="<?= htmlspecialchars($p['nama']) ?>">[<?= $p['kode'] ?>] <?= htmlspecialchars($p['nama']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2"><label class="form-label-glass">Jumlah</label><input type="number" id="inpQty" class="form-control form-control-glass" min="1" value="10"></div>
                <div class="col-md-3"><label class="form-label-glass">Harga Beli/unit</label><input type="number" id="inpPrice" class="form-control form-control-glass" min="0"></div>
                <div class="col-md-2"><button type="button" class="btn btn-primary-glass w-100" onclick="addItem()"><i class="bi bi-plus"></i> Tambah</button></div>
            </div>
        </div>
    </div>

    <!-- Items Table -->
    <div class="card-glass mb-4">
        <div class="card-header">Item PO</div>
        <div class="card-body p-0">
            <table class="table-glass" id="itemsTable">
                <thead><tr><th>Produk</th><th>Jumlah</th><th>Harga/unit</th><th>Subtotal</th><th></th></tr></thead>
                <tbody id="itemsBody"></tbody>
                <tfoot>
                    <tr><td colspan="3" style="text-align:right;font-weight:700;color:var(--text-bright)">TOTAL</td>
                    <td style="font-weight:800;color:var(--accent);font-size:16px" id="poTotal">Rp 0</td><td></td></tr>
                </tfoot>
            </table>
        </div>
    </div>

    <button type="submit" class="btn btn-primary-glass btn-lg"><i class="bi bi-save me-2"></i>Simpan Purchase Order</button>
</form>

<script>
let poItems = [];

document.getElementById('selProduk')?.addEventListener('change', function() {
    const opt = this.options[this.selectedIndex];
    if (opt.value) document.getElementById('inpPrice').value = opt.dataset.price || 0;
});

function addItem() {
    const sel = document.getElementById('selProduk');
    const opt = sel.options[sel.selectedIndex];
    if (!opt.value) return alert('Pilih produk!');
    const qty = parseInt(document.getElementById('inpQty').value) || 0;
    const price = parseFloat(document.getElementById('inpPrice').value) || 0;
    if (qty <= 0) return alert('Jumlah harus > 0');

    if (poItems.find(i => i.id == opt.value)) return alert('Produk sudah ada di daftar!');
    poItems.push({ id: opt.value, name: opt.dataset.name, jumlah: qty, harga: price });
    renderItems();
}

function addLowStockItem(p) {
    if (poItems.find(i => i.id == p.id)) return alert('Sudah ditambahkan!');
    const orderQty = Math.max(p.stok_minimum * 2 - p.stok, p.stok_minimum);
    poItems.push({ id: p.id, name: p.nama, jumlah: orderQty, harga: p.harga_beli });
    renderItems();
}

function removeItem(idx) { poItems.splice(idx, 1); renderItems(); }

function renderItems() {
    const body = document.getElementById('itemsBody');
    let html = '', total = 0;
    poItems.forEach((item, i) => {
        const sub = item.harga * item.jumlah;
        total += sub;
        html += `<tr><td>${item.name}</td><td>${item.jumlah}</td><td>Rp ${item.harga.toLocaleString('id-ID')}</td><td>Rp ${sub.toLocaleString('id-ID')}</td><td><button type="button" class="btn-sm-icon danger" onclick="removeItem(${i})"><i class="bi bi-x"></i></button></td></tr>`;
    });
    if (poItems.length === 0) html = '<tr><td colspan="5" class="text-center" style="color:var(--text-muted);padding:24px">Belum ada item</td></tr>';
    body.innerHTML = html;
    document.getElementById('poTotal').textContent = 'Rp ' + total.toLocaleString('id-ID');
}

document.getElementById('poForm')?.addEventListener('submit', function(e) {
    if (poItems.length === 0) { e.preventDefault(); alert('Tambahkan minimal 1 item!'); return; }
    document.getElementById('itemsData').value = JSON.stringify(poItems);
});

renderItems();
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
