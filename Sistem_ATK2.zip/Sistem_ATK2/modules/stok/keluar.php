<?php
$pageTitle = 'Barang Keluar';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

$products = []; $r = $conn->query("SELECT id,kode,nama,stok FROM produk WHERE is_active=1 AND stok>0 ORDER BY nama");
if ($r) while($row = $r->fetch_assoc()) $products[] = $row;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produk_id = (int)$_POST['produk_id'];
    $jumlah = (int)$_POST['jumlah'];
    $tipe = sanitize($conn, $_POST['tipe']);
    $tanggal = sanitize($conn, $_POST['tanggal']);
    $keterangan = sanitize($conn, $_POST['keterangan']);
    $uid = $_SESSION['user_id'];

    $stokNow = $conn->query("SELECT stok FROM produk WHERE id=$produk_id")->fetch_assoc()['stok'];
    if ($jumlah > $stokNow) {
        $error = "Jumlah melebihi stok tersedia ($stokNow)";
    } else {
        $conn->query("INSERT INTO stok_keluar (produk_id,jumlah,tanggal,tipe,keterangan,user_id) VALUES ($produk_id,$jumlah,'$tanggal','$tipe','$keterangan',$uid)");
        $conn->query("UPDATE produk SET stok=stok-$jumlah WHERE id=$produk_id");
        setFlash('success', "Stok berhasil dikurangi ($jumlah unit)");
        header('Location: index.php'); exit;
    }
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div><h1><i class="bi bi-box-arrow-up me-2"></i>Barang Keluar / Adjustment</h1></div>
    <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div>

<?php if(isset($error)): ?>
<div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);color:#fca5a5;border-radius:12px;padding:14px;margin-bottom:16px;"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div>
<?php endif; ?>

<div class="card-glass">
    <div class="card-body">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label-glass">Produk *</label>
                    <select name="produk_id" class="form-select form-select-glass" required>
                        <option value="">-- Pilih Produk --</option>
                        <?php foreach($products as $p): ?>
                        <option value="<?= $p['id'] ?>">[<?= $p['kode'] ?>] <?= htmlspecialchars($p['nama']) ?> (Stok: <?= $p['stok'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Tipe Pengurangan</label>
                    <select name="tipe" class="form-select form-select-glass">
                        <option value="adjustment">Adjustment</option>
                        <option value="rusak">Barang Rusak</option>
                        <option value="retur">Retur</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Jumlah *</label>
                    <input type="number" name="jumlah" class="form-control form-control-glass" required min="1">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Tanggal *</label>
                    <input type="date" name="tanggal" class="form-control form-control-glass" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Keterangan</label>
                    <textarea name="keterangan" class="form-control form-control-glass" rows="2"></textarea>
                </div>
                <div class="col-12"><button type="submit" class="btn btn-primary-glass"><i class="bi bi-save me-2"></i>Simpan</button></div>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
