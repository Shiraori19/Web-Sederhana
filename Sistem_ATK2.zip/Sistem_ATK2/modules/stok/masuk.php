<?php
$pageTitle = 'Barang Masuk';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div><h1><i class="bi bi-box-arrow-in-down me-2"></i>Barang Masuk</h1><p>Penambahan stok melalui Purchase Order</p></div>
    <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div>

<div class="card-glass" style="border-color:rgba(6,182,212,0.3);">
    <div class="card-body" style="padding:40px;text-align:center;">
        <div style="width:80px;height:80px;border-radius:24px;background:rgba(6,182,212,0.12);display:flex;align-items:center;justify-content:center;font-size:36px;color:var(--accent);margin:0 auto 24px;">
            <i class="bi bi-clipboard-check"></i>
        </div>
        <h2 style="font-size:20px;font-weight:700;color:var(--text-bright);margin-bottom:12px;">Penambahan Stok Wajib Melalui Purchase Order</h2>
        <p style="color:var(--text-muted);max-width:520px;margin:0 auto 28px;line-height:1.7;">
            Untuk menjaga keakuratan data inventaris, penambahan stok barang hanya dapat dilakukan melalui alur
            <strong style="color:var(--text-bright)">Purchase Order (PO)</strong>. Barang baru akan tercatat di sistem
            setelah PO dikonfirmasi diterima oleh gudang.
        </p>

        <!-- Alur Visual -->
        <div style="display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;margin-bottom:32px;">
            <div style="background:var(--dark-3);border:1px solid var(--border);border-radius:12px;padding:14px 20px;text-align:center;min-width:120px;">
                <div style="font-size:22px;color:var(--primary);margin-bottom:6px;"><i class="bi bi-clipboard-plus"></i></div>
                <div style="font-size:12px;font-weight:600;color:var(--text-bright);">1. Buat PO</div>
                <div style="font-size:11px;color:var(--text-muted);">Admin</div>
            </div>
            <div style="color:var(--text-muted);font-size:20px;"><i class="bi bi-arrow-right"></i></div>
            <div style="background:var(--dark-3);border:1px solid var(--border);border-radius:12px;padding:14px 20px;text-align:center;min-width:120px;">
                <div style="font-size:22px;color:var(--warning);margin-bottom:6px;"><i class="bi bi-send"></i></div>
                <div style="font-size:12px;font-weight:600;color:var(--text-bright);">2. Kirim ke Supplier</div>
                <div style="font-size:11px;color:var(--text-muted);">Admin</div>
            </div>
            <div style="color:var(--text-muted);font-size:20px;"><i class="bi bi-arrow-right"></i></div>
            <div style="background:var(--dark-3);border:1px solid rgba(16,185,129,0.3);border-radius:12px;padding:14px 20px;text-align:center;min-width:120px;">
                <div style="font-size:22px;color:var(--success);margin-bottom:6px;"><i class="bi bi-check-circle"></i></div>
                <div style="font-size:12px;font-weight:600;color:var(--text-bright);">3. Konfirmasi Terima</div>
                <div style="font-size:11px;color:var(--text-muted);">Gudang</div>
            </div>
            <div style="color:var(--text-muted);font-size:20px;"><i class="bi bi-arrow-right"></i></div>
            <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.3);border-radius:12px;padding:14px 20px;text-align:center;min-width:120px;">
                <div style="font-size:22px;color:var(--success);margin-bottom:6px;"><i class="bi bi-boxes"></i></div>
                <div style="font-size:12px;font-weight:600;color:var(--success);">Stok Bertambah</div>
                <div style="font-size:11px;color:var(--text-muted);">Otomatis</div>
            </div>
        </div>

        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
            <?php if($_SESSION['user_role'] === 'admin'): ?>
            <a href="../procurement/tambah.php" class="btn btn-primary-glass btn-lg">
                <i class="bi bi-clipboard-plus me-2"></i>Buat Purchase Order Baru
            </a>
            <?php endif; ?>
            <a href="../procurement/index.php" class="btn btn-outline-glass btn-lg">
                <i class="bi bi-clipboard-check me-2"></i>Lihat Daftar Purchase Order
            </a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
