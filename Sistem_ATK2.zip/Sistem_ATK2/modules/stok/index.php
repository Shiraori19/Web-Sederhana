<?php
$pageTitle = 'Manajemen Stok';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

$filter = sanitize($conn, $_GET['filter'] ?? 'all');
$where = "WHERE p.is_active=1";
if ($filter === 'low') $where .= " AND p.stok <= p.stok_minimum";
elseif ($filter === 'ok') $where .= " AND p.stok > p.stok_minimum";

$products = [];
$r = $conn->query("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.kategori_id=k.id $where ORDER BY (p.stok/GREATEST(p.stok_minimum,1)) ASC");
if ($r) while($row = $r->fetch_assoc()) $products[] = $row;

$totalStock = $conn->query("SELECT SUM(stok) s FROM produk WHERE is_active=1")->fetch_assoc()['s'] ?? 0;
$lowCount = $conn->query("SELECT COUNT(*) c FROM produk WHERE stok<=stok_minimum AND is_active=1")->fetch_assoc()['c'];

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-archive me-2"></i>Stok Inventaris</h1>
        <p>Pantau dan kelola stok barang</p>
    </div>
    <div class="d-flex gap-2">
        <?php if($_SESSION['user_role'] === 'admin'): ?>
        <a href="../procurement/tambah.php" class="btn btn-primary-glass"><i class="bi bi-clipboard-plus me-2"></i>Buat Purchase Order</a>
        <?php else: ?>
        <a href="../procurement/index.php" class="btn btn-primary-glass"><i class="bi bi-clipboard-check me-2"></i>Penerimaan Barang (PO)</a>
        <?php endif; ?>
        <a href="keluar.php" class="btn btn-outline-glass"><i class="bi bi-box-arrow-up me-2"></i>Barang Keluar</a>
    </div>
</div>

<!-- Quick Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="kpi-card" style="--kpi-clr:var(--primary)">
            <div class="kpi-icon" style="background:rgba(99,102,241,0.12);color:var(--primary-light)"><i class="bi bi-boxes"></i></div>
            <div class="kpi-value"><?= number_format($totalStock) ?></div>
            <div class="kpi-label">Total Unit Stok</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="kpi-card" style="--kpi-clr:var(--success)">
            <div class="kpi-icon" style="background:rgba(16,185,129,0.12);color:var(--success)"><i class="bi bi-check-circle"></i></div>
            <div class="kpi-value"><?= count($products) - $lowCount ?></div>
            <div class="kpi-label">Stok Aman</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="kpi-card" style="--kpi-clr:var(--danger)">
            <div class="kpi-icon" style="background:rgba(239,68,68,0.12);color:var(--danger)"><i class="bi bi-exclamation-triangle"></i></div>
            <div class="kpi-value"><?= $lowCount ?></div>
            <div class="kpi-label">Stok Rendah</div>
        </div>
    </div>
</div>

<!-- Filter -->
<div class="card-glass mb-3">
    <div class="card-body py-3">
        <div class="d-flex gap-2">
            <a href="?filter=all" class="btn <?= $filter=='all'?'btn-primary-glass':'btn-outline-glass' ?> btn-sm">Semua</a>
            <a href="?filter=low" class="btn <?= $filter=='low'?'btn-primary-glass':'btn-outline-glass' ?> btn-sm">Stok Rendah</a>
            <a href="?filter=ok" class="btn <?= $filter=='ok'?'btn-primary-glass':'btn-outline-glass' ?> btn-sm">Stok Aman</a>
        </div>
    </div>
</div>

<div class="card-glass">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead><tr><th>Kode</th><th>Produk</th><th>Kategori</th><th>Stok</th><th>Minimum</th><th>Status</th><th>Satuan</th></tr></thead>
                <tbody>
                <?php foreach($products as $p): 
                    $pct = $p['stok_minimum'] > 0 ? ($p['stok']/$p['stok_minimum'])*100 : 100;
                    $status = $p['stok'] <= $p['stok_minimum'] ? 'danger' : ($pct < 200 ? 'warning' : 'success');
                ?>
                <tr>
                    <td><code style="color:var(--accent)"><?= $p['kode'] ?></code></td>
                    <td><strong><?= htmlspecialchars($p['nama']) ?></strong></td>
                    <td><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></td>
                    <td><strong style="color:var(--<?= $status ?>)"><?= $p['stok'] ?></strong></td>
                    <td><?= $p['stok_minimum'] ?></td>
                    <td>
                        <div style="width:80px;height:6px;background:var(--dark-3);border-radius:3px;overflow:hidden">
                            <div style="width:<?= min($pct,100) ?>%;height:100%;background:var(--<?= $status ?>);border-radius:3px"></div>
                        </div>
                    </td>
                    <td><?= $p['satuan'] ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
