<?php
$pageTitle = 'Riwayat Penjualan';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','kasir']);

$dateFrom = sanitize($conn, $_GET['from'] ?? date('Y-m-d', strtotime('-30 days')));
$dateTo = sanitize($conn, $_GET['to'] ?? date('Y-m-d'));
$channel = sanitize($conn, $_GET['channel'] ?? '');
$metode = sanitize($conn, $_GET['metode'] ?? '');

$where = "WHERE pj.status='selesai' AND DATE(pj.tanggal) BETWEEN '$dateFrom' AND '$dateTo'";
if ($channel) $where .= " AND pj.channel='$channel'";
if ($metode) $where .= " AND pj.metode_bayar='$metode'";

$transactions = [];
$r = $conn->query("SELECT pj.*, pl.nama as pelanggan_nama, u.nama as kasir_nama FROM penjualan pj LEFT JOIN pelanggan pl ON pj.pelanggan_id=pl.id LEFT JOIN users u ON pj.user_id=u.id $where ORDER BY pj.tanggal DESC LIMIT 100");
if ($r) while($row = $r->fetch_assoc()) $transactions[] = $row;

$totalRevenue = $conn->query("SELECT COALESCE(SUM(grand_total),0) s FROM penjualan pj $where")->fetch_assoc()['s'];
$totalTx = count($transactions);

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div><h1><i class="bi bi-receipt me-2"></i>Riwayat Penjualan</h1><p>Riwayat semua transaksi penjualan</p></div>
</div>

<!-- Filters -->
<div class="card-glass mb-4">
    <div class="card-body py-3">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-md-2"><label class="form-label-glass">Dari</label><input type="date" name="from" class="form-control form-control-glass" value="<?= $dateFrom ?>"></div>
            <div class="col-md-2"><label class="form-label-glass">Sampai</label><input type="date" name="to" class="form-control form-control-glass" value="<?= $dateTo ?>"></div>
            <div class="col-md-2">
                <label class="form-label-glass">Channel</label>
                <select name="channel" class="form-select form-select-glass">
                    <option value="">Semua</option>
                    <?php foreach(['toko','shopee','tokopedia','website'] as $ch): ?>
                    <option value="<?= $ch ?>" <?= $channel==$ch?'selected':'' ?>><?= ucfirst($ch) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label-glass">Metode</label>
                <select name="metode" class="form-select form-select-glass">
                    <option value="">Semua</option>
                    <?php foreach(['cash','qris','ewallet','transfer'] as $m): ?>
                    <option value="<?= $m ?>" <?= $metode==$m?'selected':'' ?>><?= ucfirst($m) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2"><button class="btn btn-primary-glass w-100"><i class="bi bi-funnel me-1"></i>Filter</button></div>
            <div class="col-md-2"><a href="riwayat.php" class="btn btn-outline-glass w-100">Reset</a></div>
        </form>
    </div>
</div>

<!-- Summary -->
<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="kpi-card" style="--kpi-clr:var(--primary)">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon" style="background:rgba(99,102,241,0.12);color:var(--primary-light)"><i class="bi bi-receipt-cutoff"></i></div>
                <div><div class="kpi-value"><?= $totalTx ?></div><div class="kpi-label">Total Transaksi</div></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="kpi-card" style="--kpi-clr:var(--success)">
            <div class="d-flex align-items-center gap-3">
                <div class="kpi-icon" style="background:rgba(16,185,129,0.12);color:var(--success)"><i class="bi bi-cash-stack"></i></div>
                <div><div class="kpi-value"><?= formatRupiah($totalRevenue) ?></div><div class="kpi-label">Total Revenue</div></div>
            </div>
        </div>
    </div>
</div>

<!-- Table -->
<div class="card-glass">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead><tr><th>Invoice</th><th>Tanggal</th><th>Pelanggan</th><th>Channel</th><th>Metode</th><th>Total</th><th>Kasir</th><th>Detail</th></tr></thead>
                <tbody>
                <?php foreach($transactions as $tx): ?>
                <tr>
                    <td><strong><?= $tx['no_invoice'] ?></strong></td>
                    <td><?= date('d/m/Y H:i', strtotime($tx['tanggal'])) ?></td>
                    <td><?= htmlspecialchars($tx['pelanggan_nama'] ?? 'Walk-in') ?></td>
                    <td><span class="badge-status badge-info"><?= ucfirst($tx['channel']) ?></span></td>
                    <td><span class="badge-status badge-primary"><?= strtoupper($tx['metode_bayar']) ?></span></td>
                    <td><strong><?= formatRupiah($tx['grand_total']) ?></strong></td>
                    <td style="color:var(--text-muted)"><?= htmlspecialchars($tx['kasir_nama'] ?? '-') ?></td>
                    <td>
                        <div class="d-flex gap-1">
                            <button class="btn-sm-icon" onclick="showDetail(<?= $tx['id'] ?>)" title="Detail"><i class="bi bi-eye"></i></button>
                            <a href="invoice.php?id=<?= $tx['id'] ?>" class="btn-sm-icon" title="Invoice / Print" target="_blank"><i class="bi bi-printer"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($transactions)): ?>
                <tr><td colspan="8" class="empty-state-dash">Tidak ada transaksi ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Detail Modal -->
<div class="modal fade" id="detailModal"><div class="modal-dialog modal-lg"><div class="modal-content modal-content-glass">
    <div class="modal-header"><h5 class="modal-title"><i class="bi bi-receipt me-2"></i>Detail Transaksi</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body" id="detailBody">Loading...</div>
</div></div></div>

<script>
function showDetail(id) {
    const modal = new bootstrap.Modal(document.getElementById('detailModal'));
    const body = document.getElementById('detailBody');
    body.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"></div></div>';
    modal.show();

    fetch('?ajax_detail=' + id).then(r => r.text()).then(html => { body.innerHTML = html; });
}
</script>

<?php
// AJAX detail handler
if (isset($_GET['ajax_detail'])) {
    $id = (int)$_GET['ajax_detail'];
    $tx = $conn->query("SELECT pj.*, pl.nama as pelanggan_nama FROM penjualan pj LEFT JOIN pelanggan pl ON pj.pelanggan_id=pl.id WHERE pj.id=$id")->fetch_assoc();
    $items = [];
    $r = $conn->query("SELECT dp.*, p.nama, p.kode FROM detail_penjualan dp JOIN produk p ON dp.produk_id=p.id WHERE dp.penjualan_id=$id");
    if ($r) while($row = $r->fetch_assoc()) $items[] = $row;
    
    echo '<div class="mb-3"><strong>Invoice:</strong> '.$tx['no_invoice'].'<br><strong>Tanggal:</strong> '.date('d M Y H:i', strtotime($tx['tanggal'])).'<br><strong>Pelanggan:</strong> '.htmlspecialchars($tx['pelanggan_nama'] ?? 'Walk-in').'</div>';
    echo '<table class="table-glass"><thead><tr><th>Produk</th><th>Qty</th><th>Harga</th><th>Subtotal</th></tr></thead><tbody>';
    foreach ($items as $it) {
        echo '<tr><td>'.htmlspecialchars($it['nama']).'</td><td>'.$it['jumlah'].'</td><td>'.formatRupiah($it['harga']).'</td><td>'.formatRupiah($it['subtotal']).'</td></tr>';
    }
    echo '</tbody></table>';
    echo '<div class="mt-3" style="text-align:right"><div>Subtotal: '.formatRupiah($tx['total']).'</div><div>Diskon: '.formatRupiah($tx['diskon']).'</div><div style="font-size:18px;font-weight:700;color:var(--accent)">Grand Total: '.formatRupiah($tx['grand_total']).'</div></div>';
    exit;
}

include __DIR__ . '/../../includes/footer.php';
?>
