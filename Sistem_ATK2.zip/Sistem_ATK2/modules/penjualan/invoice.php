<?php
/**
 * Invoice / Bukti Pembayaran — Ketoeroenan Doeloe v2
 * Halaman ini menampilkan struk yang bisa di-print
 */
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','kasir']);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: riwayat.php'); exit; }

// Fetch transaction
$tx = $conn->query("SELECT pj.*, pl.nama as pelanggan_nama, pl.telepon as pelanggan_telp, pl.level as pelanggan_level, u.nama as kasir_nama 
FROM penjualan pj 
LEFT JOIN pelanggan pl ON pj.pelanggan_id=pl.id 
LEFT JOIN users u ON pj.user_id=u.id 
WHERE pj.id=$id")->fetch_assoc();

if (!$tx) { header('Location: riwayat.php'); exit; }

// Fetch items
$items = [];
$r = $conn->query("SELECT dp.*, p.nama as produk_nama, p.kode as produk_kode FROM detail_penjualan dp JOIN produk p ON dp.produk_id=p.id WHERE dp.penjualan_id=$id ORDER BY dp.id");
if ($r) while($row = $r->fetch_assoc()) $items[] = $row;

$totalItems = array_sum(array_column($items, 'jumlah'));

// Check loyalty points earned
$pointsEarned = 0;
if ($tx['pelanggan_id'] && in_array($tx['metode_bayar'], ['qris','ewallet','transfer'])) {
    $pointsEarned = floor($tx['grand_total'] / 10000);
}

$metodeBayarLabel = [
    'cash' => '💵 Cash / Tunai',
    'qris' => '📱 QRIS',
    'ewallet' => '💳 E-Wallet',
    'transfer' => '🏦 Transfer Bank'
];

$channelLabel = [
    'toko' => '🏪 Toko Fisik',
    'shopee' => '🟠 Shopee',
    'tokopedia' => '🟢 Tokopedia',
    'website' => '🌐 Website'
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?= $tx['no_invoice'] ?> — Ketoeroenan Doeloe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --primary:#6366f1; --dark:#0f172a; --dark-2:#1e293b; --border:rgba(99,102,241,0.15); --text:#e2e8f0; --text-muted:#94a3b8; --accent:#06b6d4; --success:#10b981; }
        
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Inter',sans-serif; background:var(--dark); color:var(--text); min-height:100vh; }
        
        /* Screen Layout */
        .invoice-page { max-width:800px; margin:0 auto; padding:24px; }
        
        .toolbar {
            display:flex; justify-content:space-between; align-items:center;
            margin-bottom:24px; padding:16px 20px;
            background:var(--dark-2); border:1px solid var(--border); border-radius:14px;
        }
        .toolbar a, .toolbar button { text-decoration:none; display:inline-flex; align-items:center; gap:8px; padding:10px 20px; border-radius:10px; font-weight:600; font-size:13px; cursor:pointer; transition:all 0.3s; border:none; }
        .btn-back { background:transparent; border:1px solid var(--border); color:var(--text-muted); }
        .btn-back:hover { border-color:var(--primary); color:var(--primary); }
        .btn-print { background:linear-gradient(135deg,var(--primary),#8b5cf6); color:#fff; }
        .btn-print:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(99,102,241,0.4); }
        .btn-new { background:var(--success); color:#fff; }
        .btn-new:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(16,185,129,0.4); }
        
        /* Invoice Card */
        .invoice-card {
            background:var(--dark-2); border:1px solid var(--border); border-radius:20px;
            overflow:hidden;
        }
        
        /* Header */
        .inv-header {
            background:linear-gradient(135deg, rgba(99,102,241,0.15), rgba(139,92,246,0.1));
            padding:32px; border-bottom:1px solid var(--border);
        }
        .inv-header-top { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:20px; }
        .inv-brand { display:flex; align-items:center; gap:12px; }
        .inv-brand-icon { width:48px; height:48px; background:linear-gradient(135deg,var(--primary),#8b5cf6); border-radius:14px; display:flex; align-items:center; justify-content:center; font-size:22px; color:#fff; }
        .inv-brand h2 { font-size:20px; font-weight:800; color:#f1f5f9; }
        .inv-brand small { display:block; font-size:11px; color:var(--text-muted); font-weight:400; }
        .inv-status { padding:6px 14px; border-radius:8px; font-size:12px; font-weight:700; background:rgba(16,185,129,0.15); color:#6ee7b7; }
        
        .inv-meta { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
        .inv-meta-item { }
        .inv-meta-label { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:var(--text-muted); font-weight:600; margin-bottom:2px; }
        .inv-meta-value { font-size:14px; font-weight:600; color:#f1f5f9; }
        .inv-meta-value.highlight { color:var(--accent); }
        
        /* Body */
        .inv-body { padding:32px; }
        
        .inv-section-title { font-size:11px; text-transform:uppercase; letter-spacing:1px; color:var(--text-muted); font-weight:600; margin-bottom:12px; display:flex; align-items:center; gap:8px; }
        .inv-section-title::after { content:''; flex:1; height:1px; background:var(--border); }
        
        /* Items Table */
        .inv-table { width:100%; border-collapse:collapse; margin-bottom:24px; }
        .inv-table th { font-size:10px; text-transform:uppercase; letter-spacing:0.5px; color:var(--text-muted); font-weight:600; padding:10px 12px; text-align:left; border-bottom:1px solid var(--border); }
        .inv-table th:nth-child(3), .inv-table th:nth-child(4) { text-align:right; }
        .inv-table td { padding:12px; border-bottom:1px solid rgba(99,102,241,0.06); font-size:13px; }
        .inv-table td:nth-child(3), .inv-table td:nth-child(4) { text-align:right; }
        .inv-table .prod-name { font-weight:600; color:#f1f5f9; }
        .inv-table .prod-code { font-size:11px; color:var(--text-muted); }
        .inv-table tbody tr:hover { background:rgba(99,102,241,0.03); }
        
        /* Summary */
        .inv-summary { display:flex; justify-content:flex-end; margin-bottom:24px; }
        .inv-summary-box { width:300px; }
        .inv-sum-row { display:flex; justify-content:space-between; padding:8px 0; font-size:13px; color:var(--text-muted); }
        .inv-sum-row.total { font-size:20px; font-weight:800; color:#f1f5f9; border-top:2px solid var(--border); padding-top:12px; margin-top:4px; }
        .inv-sum-row .val { font-weight:600; color:var(--text); }
        .inv-sum-row.total .val { color:var(--accent); }
        
        /* Payment Info */
        .inv-payment { display:grid; grid-template-columns:1fr 1fr; gap:16px; padding:24px; background:rgba(99,102,241,0.04); border-radius:14px; margin-bottom:24px; }
        .inv-pay-item .label { font-size:10px; text-transform:uppercase; letter-spacing:1px; color:var(--text-muted); font-weight:600; }
        .inv-pay-item .value { font-size:14px; font-weight:600; color:#f1f5f9; margin-top:2px; }
        .inv-pay-item .value.success { color:var(--success); }
        
        /* Loyalty Points Badge */
        .inv-loyalty {
            display:flex; align-items:center; gap:12px; padding:16px 20px;
            background:linear-gradient(135deg, rgba(245,158,11,0.1), rgba(245,158,11,0.05));
            border:1px solid rgba(245,158,11,0.2); border-radius:12px; margin-bottom:24px;
        }
        .inv-loyalty-icon { width:40px; height:40px; background:rgba(245,158,11,0.15); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; color:#fcd34d; }
        .inv-loyalty-text { font-size:13px; color:#fcd34d; font-weight:500; }
        .inv-loyalty-text strong { font-size:16px; }
        
        /* Footer */
        .inv-footer { text-align:center; padding:24px; border-top:1px solid var(--border); }
        .inv-footer p { font-size:12px; color:var(--text-muted); margin-bottom:4px; }
        .inv-footer .thanks { font-size:16px; font-weight:700; color:var(--primary); margin-bottom:8px; }
        
        /* ===== PRINT STYLES ===== */
        @media print {
            @page { margin:10mm; size:80mm auto; }
            body { background:#fff !important; color:#333 !important; font-size:11px; }
            .toolbar { display:none !important; }
            .invoice-page { max-width:100%; padding:0; }
            .invoice-card { border:none; border-radius:0; background:#fff !important; }
            .inv-header { background:none !important; padding:16px 0; border-bottom:2px solid #333; }
            .inv-brand-icon { display:none; }
            .inv-brand h2 { color:#000 !important; }
            .inv-brand small { color:#666 !important; }
            .inv-meta-label { color:#666 !important; }
            .inv-meta-value { color:#000 !important; }
            .inv-status { background:#eee !important; color:#333 !important; }
            .inv-body { padding:16px 0; }
            .inv-table th { background:none; color:#666 !important; border-bottom:1px solid #333; }
            .inv-table td { color:#333 !important; border-bottom:1px solid #eee; }
            .prod-name { color:#000 !important; }
            .prod-code { color:#666 !important; }
            .inv-sum-row { color:#666 !important; }
            .inv-sum-row .val { color:#333 !important; }
            .inv-sum-row.total { border-top-color:#333; }
            .inv-sum-row.total .val { color:#000 !important; }
            .inv-payment { background:#f8f8f8 !important; border:1px solid #ddd; }
            .inv-pay-item .label { color:#666 !important; }
            .inv-pay-item .value { color:#000 !important; }
            .inv-loyalty { background:#fffbeb !important; border-color:#fbbf24; }
            .inv-loyalty-icon { background:none; color:#d97706 !important; }
            .inv-loyalty-text { color:#92400e !important; }
            .inv-footer p { color:#999 !important; }
            .inv-footer .thanks { color:#333 !important; }
            .inv-section-title { color:#666 !important; }
            .inv-section-title::after { background:#ddd; }
        }
        
        /* Thermal printer size (80mm) */
        @media print and (max-width:80mm) {
            .inv-meta { grid-template-columns:1fr; }
            .inv-payment { grid-template-columns:1fr; }
            .inv-table th:nth-child(1), .inv-table td:nth-child(1) { display:none; }
        }
    </style>
</head>
<body>
    <div class="invoice-page">
        <!-- Toolbar (hidden on print) -->
        <div class="toolbar">
            <div class="d-flex" style="display:flex;gap:8px;">
                <a href="kasir.php" class="btn-back"><i class="bi bi-cart3"></i> Transaksi Baru</a>
                <a href="riwayat.php" class="btn-back"><i class="bi bi-arrow-left"></i> Riwayat</a>
            </div>
            <div style="display:flex;gap:8px;">
                <button onclick="window.print()" class="btn-print"><i class="bi bi-printer"></i> Print Struk</button>
            </div>
        </div>

        <!-- Invoice Card -->
        <div class="invoice-card">
            <!-- Header -->
            <div class="inv-header">
                <div class="inv-header-top">
                    <div class="inv-brand">
                        <div class="inv-brand-icon"><i class="bi bi-shop"></i></div>
                        <div>
                            <h2>Ketoeroenan Doeloe</h2>
                            <small>Sistem Informasi Toko Alat Tulis Kantor</small>
                        </div>
                    </div>
                    <div class="inv-status"><i class="bi bi-check-circle me-1"></i> LUNAS</div>
                </div>
                
                <div class="inv-meta">
                    <div class="inv-meta-item">
                        <div class="inv-meta-label">No. Invoice</div>
                        <div class="inv-meta-value highlight"><?= $tx['no_invoice'] ?></div>
                    </div>
                    <div class="inv-meta-item">
                        <div class="inv-meta-label">Tanggal & Waktu</div>
                        <div class="inv-meta-value"><?= date('d F Y, H:i', strtotime($tx['tanggal'])) ?> WIB</div>
                    </div>
                    <div class="inv-meta-item">
                        <div class="inv-meta-label">Pelanggan</div>
                        <div class="inv-meta-value"><?= htmlspecialchars($tx['pelanggan_nama'] ?? 'Walk-in Customer') ?></div>
                    </div>
                    <div class="inv-meta-item">
                        <div class="inv-meta-label">Kasir</div>
                        <div class="inv-meta-value"><?= htmlspecialchars($tx['kasir_nama'] ?? '-') ?></div>
                    </div>
                </div>
            </div>

            <!-- Body -->
            <div class="inv-body">
                <!-- Items -->
                <div class="inv-section-title">Detail Pembelian (<?= $totalItems ?> item)</div>
                <table class="inv-table">
                    <thead>
                        <tr>
                            <th style="width:60px">Kode</th>
                            <th>Produk</th>
                            <th style="width:90px">Qty × Harga</th>
                            <th style="width:120px">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td><span class="prod-code"><?= $item['produk_kode'] ?></span></td>
                            <td><span class="prod-name"><?= htmlspecialchars($item['produk_nama']) ?></span></td>
                            <td><?= $item['jumlah'] ?> × <?= formatRupiah($item['harga']) ?></td>
                            <td><strong><?= formatRupiah($item['subtotal']) ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Summary -->
                <div class="inv-summary">
                    <div class="inv-summary-box">
                        <div class="inv-sum-row"><span>Subtotal</span><span class="val"><?= formatRupiah($tx['total']) ?></span></div>
                        <?php if ($tx['diskon'] > 0): ?>
                        <div class="inv-sum-row"><span>Diskon</span><span class="val" style="color:#ef4444">- <?= formatRupiah($tx['diskon']) ?></span></div>
                        <?php endif; ?>
                        <div class="inv-sum-row total"><span>Total</span><span class="val"><?= formatRupiah($tx['grand_total']) ?></span></div>
                    </div>
                </div>

                <!-- Payment Info -->
                <div class="inv-section-title">Informasi Pembayaran</div>
                <div class="inv-payment">
                    <div class="inv-pay-item">
                        <div class="label">Metode Pembayaran</div>
                        <div class="value"><?= $metodeBayarLabel[$tx['metode_bayar']] ?? ucfirst($tx['metode_bayar']) ?></div>
                    </div>
                    <div class="inv-pay-item">
                        <div class="label">Channel Penjualan</div>
                        <div class="value"><?= $channelLabel[$tx['channel']] ?? ucfirst($tx['channel']) ?></div>
                    </div>
                    <div class="inv-pay-item">
                        <div class="label">Jumlah Bayar</div>
                        <div class="value"><?= formatRupiah($tx['bayar']) ?></div>
                    </div>
                    <div class="inv-pay-item">
                        <div class="label">Kembalian</div>
                        <div class="value success"><?= formatRupiah($tx['kembalian']) ?></div>
                    </div>
                </div>

                <!-- Loyalty Points -->
                <?php if ($pointsEarned > 0): ?>
                <div class="inv-loyalty">
                    <div class="inv-loyalty-icon"><i class="bi bi-star-fill"></i></div>
                    <div class="inv-loyalty-text">
                        Anda mendapatkan <strong>+<?= $pointsEarned ?> Poin</strong> Loyalitas dari transaksi ini!<br>
                        <small>Member <?= $tx['pelanggan_level'] ?> • Pembayaran digital mendapatkan 1 poin per Rp 10.000</small>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Footer -->
            <div class="inv-footer">
                <div class="thanks">Terima Kasih! 🙏</div>
                <p>Barang yang sudah dibeli tidak dapat dikembalikan</p>
                <p>Ketoeroenan Doeloe v2.0 — <?= date('Y') ?></p>
            </div>
        </div>
    </div>
</body>
</html>
