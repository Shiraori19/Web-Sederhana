<?php
$pageTitle = 'Kasir / POS';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','kasir']);

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    $cart = json_decode($_POST['cart_data'], true);
    $metode = sanitize($conn, $_POST['metode_bayar']);
    $channel = sanitize($conn, $_POST['channel']);
    $pelangganId = (int)$_POST['pelanggan_id'] ?: null;
    $bayar = (float)$_POST['bayar'];
    $diskon = (float)$_POST['diskon'];

    if (empty($cart)) { setFlash('error', 'Keranjang kosong!'); header('Location: kasir.php'); exit; }

    $total = 0;
    foreach ($cart as $item) $total += $item['harga'] * $item['qty'];
    $grandTotal = $total - $diskon;
    $kembalian = $bayar - $grandTotal;

    $invoice = generateInvoice();
    $uid = $_SESSION['user_id'];
    $now = date('Y-m-d H:i:s');
    $pelIdSql = $pelangganId ?: 'NULL';

    $conn->query("INSERT INTO penjualan (no_invoice,pelanggan_id,total,diskon,grand_total,bayar,kembalian,metode_bayar,channel,status,tanggal,user_id) VALUES ('$invoice',$pelIdSql,$total,$diskon,$grandTotal,$bayar,$kembalian,'$metode','$channel','selesai','$now',$uid)");
    $saleId = $conn->insert_id;

    foreach ($cart as $item) {
        $pid = (int)$item['id'];
        $qty = (int)$item['qty'];
        $harga = (float)$item['harga'];
        $subtotal = $harga * $qty;
        $conn->query("INSERT INTO detail_penjualan (penjualan_id,produk_id,jumlah,harga,subtotal) VALUES ($saleId,$pid,$qty,$harga,$subtotal)");
        $conn->query("UPDATE produk SET stok=stok-$qty WHERE id=$pid");

        // Stock out record
        $conn->query("INSERT INTO stok_keluar (produk_id,jumlah,tanggal,tipe,keterangan,user_id) VALUES ($pid,$qty,'".date('Y-m-d')."','penjualan','Invoice: $invoice',$uid)");
    }

    // Loyalty points for digital payment
    if ($pelangganId && in_array($metode, ['qris','ewallet','transfer'])) {
        $points = floor($grandTotal / 10000);
        $conn->query("UPDATE pelanggan SET poin_loyalitas=poin_loyalitas+$points, total_belanja=total_belanja+$grandTotal WHERE id=$pelangganId");
        // Update level
        $pel = $conn->query("SELECT total_belanja FROM pelanggan WHERE id=$pelangganId")->fetch_assoc();
        $tb = $pel['total_belanja'];
        $level = 'Bronze';
        if ($tb >= 10000000) $level = 'Platinum';
        elseif ($tb >= 5000000) $level = 'Gold';
        elseif ($tb >= 1000000) $level = 'Silver';
        $conn->query("UPDATE pelanggan SET level='$level' WHERE id=$pelangganId");
    }

    setFlash('success', "Transaksi berhasil! Invoice: $invoice | Total: " . formatRupiah($grandTotal));
    header("Location: invoice.php?id=$saleId"); exit;
}

// Fetch data
$products = [];
$r = $conn->query("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.kategori_id=k.id WHERE p.is_active=1 AND p.stok>0 ORDER BY p.nama");
if ($r) while($row = $r->fetch_assoc()) $products[] = $row;

$categories = [];
$r = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori");
if ($r) while($row = $r->fetch_assoc()) $categories[] = $row;

$customers = [];
$r = $conn->query("SELECT id,nama,poin_loyalitas,level FROM pelanggan ORDER BY nama");
if ($r) while($row = $r->fetch_assoc()) $customers[] = $row;

$extraCss = [BASE_URL . '/assets/css/pos.css?v=' . filemtime(__DIR__ . '/../../assets/css/pos.css')];
include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="pos-container">
    <!-- Product Grid -->
    <div class="pos-products">
        <div class="pos-search-bar">
            <div class="search-input-wrap">
                <i class="bi bi-search"></i>
                <input type="text" id="searchProduct" placeholder="Cari produk..." class="form-control-glass">
            </div>
            <select id="filterCategory" class="form-select-glass" style="max-width:200px">
                <option value="">Semua Kategori</option>
                <?php foreach($categories as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nama_kategori']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="products-grid" id="productsGrid">
            <?php foreach($products as $p): ?>
            <div class="pos-product-card" data-id="<?= $p['id'] ?>" data-name="<?= htmlspecialchars($p['nama']) ?>" data-price="<?= $p['harga_jual'] ?>" data-stock="<?= $p['stok'] ?>" data-category="<?= $p['kategori_id'] ?>" onclick="addToCart(this)">
                <div class="pos-prod-icon"><i class="bi bi-box-seam"></i></div>
                <div class="pos-prod-name"><?= htmlspecialchars($p['nama']) ?></div>
                <div class="pos-prod-code"><?= $p['kode'] ?></div>
                <div class="pos-prod-price"><?= formatRupiah($p['harga_jual']) ?></div>
                <div class="pos-prod-stock <?= $p['stok']<=$p['stok_minimum']?'low':'' ?>">Stok: <?= $p['stok'] ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Cart Sidebar -->
    <div class="pos-cart">
        <div class="cart-header">
            <h3><i class="bi bi-cart3 me-2"></i>Keranjang</h3>
            <button class="btn-sm-icon danger" onclick="clearCart()" title="Kosongkan"><i class="bi bi-trash"></i></button>
        </div>

        <div class="cart-items" id="cartItems">
            <div class="cart-empty" id="cartEmpty">
                <i class="bi bi-cart-x"></i>
                <p>Keranjang kosong</p>
            </div>
        </div>

        <div class="cart-summary">
            <div class="summary-row"><span>Subtotal</span><span id="subtotal">Rp 0</span></div>
            <div class="summary-row">
                <span>Diskon (Rp)</span>
                <input type="number" id="diskonInput" value="0" min="0" class="form-control-glass" style="width:120px;text-align:right;padding:4px 8px;" onchange="updateTotal()">
            </div>
            <div class="summary-row total"><span>TOTAL</span><span id="grandTotal">Rp 0</span></div>
        </div>

        <form method="POST" id="checkoutForm">
            <input type="hidden" name="checkout" value="1">
            <input type="hidden" name="cart_data" id="cartDataInput">
            <input type="hidden" name="diskon" id="diskonHidden">

            <div class="cart-options">
                <div class="mb-2">
                    <label class="form-label-glass" style="font-size:11px">Pelanggan</label>
                    <select name="pelanggan_id" class="form-select form-select-glass" style="font-size:12px">
                        <option value="">Walk-in Customer</option>
                        <?php foreach($customers as $c): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nama']) ?> (<?= $c['level'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6">
                        <label class="form-label-glass" style="font-size:11px">Metode Bayar</label>
                        <select name="metode_bayar" class="form-select form-select-glass" style="font-size:12px">
                            <option value="cash">💵 Cash</option>
                            <option value="qris">📱 QRIS</option>
                            <option value="ewallet">💳 E-Wallet</option>
                            <option value="transfer">🏦 Transfer</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label-glass" style="font-size:11px">Channel</label>
                        <select name="channel" class="form-select form-select-glass" style="font-size:12px">
                            <option value="toko">🏪 Toko Fisik</option>
                            <option value="shopee">🟠 Shopee</option>
                            <option value="tokopedia">🟢 Tokopedia</option>
                            <option value="website">🌐 Website</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label-glass" style="font-size:11px">Jumlah Bayar (Rp)</label>
                    <input type="number" name="bayar" id="bayarInput" class="form-control form-control-glass" min="0" style="font-size:14px;font-weight:700">
                    <div id="kembalianInfo" style="font-size:12px;color:var(--success);margin-top:4px;display:none"></div>
                </div>
            </div>

            <button type="submit" class="btn-checkout" id="btnCheckout" disabled>
                <i class="bi bi-check-circle me-2"></i>Proses Pembayaran
            </button>
        </form>
    </div>
</div>

<script>
let cart = [];

function addToCart(el) {
    const id = el.dataset.id;
    const name = el.dataset.name;
    const price = parseFloat(el.dataset.price);
    const stock = parseInt(el.dataset.stock);

    const existing = cart.find(i => i.id == id);
    if (existing) {
        if (existing.qty >= stock) { alert('Stok tidak mencukupi!'); return; }
        existing.qty++;
    } else {
        cart.push({ id, name, harga: price, qty: 1, stock });
    }
    renderCart();
}

function removeFromCart(id) {
    cart = cart.filter(i => i.id != id);
    renderCart();
}

function updateQty(id, delta) {
    const item = cart.find(i => i.id == id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) return removeFromCart(id);
    if (item.qty > item.stock) { item.qty = item.stock; alert('Stok tidak mencukupi!'); }
    renderCart();
}

function clearCart() {
    if (cart.length && confirm('Kosongkan keranjang?')) { cart = []; renderCart(); }
}

function renderCart() {
    const container = document.getElementById('cartItems');
    const empty = document.getElementById('cartEmpty');

    if (cart.length === 0) {
        container.innerHTML = '<div class="cart-empty" id="cartEmpty"><i class="bi bi-cart-x"></i><p>Keranjang kosong</p></div>';
        document.getElementById('btnCheckout').disabled = true;
    } else {
        let html = '';
        cart.forEach(item => {
            html += `<div class="cart-item">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">${formatRp(item.harga)} × ${item.qty}</div>
                </div>
                <div class="cart-item-actions">
                    <button type="button" class="btn-qty" onclick="updateQty('${item.id}',-1)">−</button>
                    <span class="qty-value">${item.qty}</span>
                    <button type="button" class="btn-qty" onclick="updateQty('${item.id}',1)">+</button>
                    <button type="button" class="btn-remove" onclick="removeFromCart('${item.id}')"><i class="bi bi-x"></i></button>
                </div>
                <div class="cart-item-subtotal">${formatRp(item.harga * item.qty)}</div>
            </div>`;
        });
        container.innerHTML = html;
        document.getElementById('btnCheckout').disabled = false;
    }
    updateTotal();
}

function updateTotal() {
    let subtotal = cart.reduce((sum, i) => sum + i.harga * i.qty, 0);
    let diskon = parseFloat(document.getElementById('diskonInput').value) || 0;
    let grandTotal = subtotal - diskon;
    if (grandTotal < 0) grandTotal = 0;

    document.getElementById('subtotal').textContent = formatRp(subtotal);
    document.getElementById('grandTotal').textContent = formatRp(grandTotal);
    document.getElementById('bayarInput').min = grandTotal;
    document.getElementById('bayarInput').value = grandTotal;

    document.getElementById('cartDataInput').value = JSON.stringify(cart);
    document.getElementById('diskonHidden').value = diskon;
}

document.getElementById('bayarInput')?.addEventListener('input', function() {
    const grandTotal = cart.reduce((s,i) => s + i.harga*i.qty, 0) - (parseFloat(document.getElementById('diskonInput').value)||0);
    const bayar = parseFloat(this.value) || 0;
    const info = document.getElementById('kembalianInfo');
    if (bayar >= grandTotal && grandTotal > 0) {
        info.style.display = 'block';
        info.textContent = 'Kembalian: ' + formatRp(bayar - grandTotal);
    } else {
        info.style.display = 'none';
    }
});

// Search & filter
document.getElementById('searchProduct')?.addEventListener('input', filterProducts);
document.getElementById('filterCategory')?.addEventListener('change', filterProducts);

function filterProducts() {
    const search = document.getElementById('searchProduct').value.toLowerCase();
    const cat = document.getElementById('filterCategory').value;
    document.querySelectorAll('.pos-product-card').forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const category = card.dataset.category;
        const show = name.includes(search) && (!cat || category == cat);
        card.style.display = show ? '' : 'none';
    });
}

function formatRp(n) { return 'Rp ' + n.toLocaleString('id-ID'); }

// Form validation
document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
    if (cart.length === 0) { e.preventDefault(); alert('Keranjang kosong!'); return; }
    document.getElementById('cartDataInput').value = JSON.stringify(cart);
    const grandTotal = cart.reduce((s,i) => s + i.harga*i.qty, 0) - (parseFloat(document.getElementById('diskonInput').value)||0);
    const bayar = parseFloat(document.getElementById('bayarInput').value) || 0;
    if (bayar < grandTotal) { e.preventDefault(); alert('Jumlah bayar kurang!'); }
});
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
