<?php
$pageTitle = 'Tambah Produk';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

$categories = [];
$r = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori");
if ($r) while($row = $r->fetch_assoc()) $categories[] = $row;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = sanitize($conn, $_POST['kode']);
    $nama = sanitize($conn, $_POST['nama']);
    $kategori_id = (int)$_POST['kategori_id'] ?: 'NULL';
    $deskripsi = sanitize($conn, $_POST['deskripsi']);
    $harga_beli = (float)$_POST['harga_beli'];
    $harga_jual = (float)$_POST['harga_jual'];
    $stok = (int)$_POST['stok'];
    $stok_minimum = (int)$_POST['stok_minimum'];
    $satuan = sanitize($conn, $_POST['satuan']);

    $stmt = $conn->prepare("INSERT INTO produk (kode,nama,kategori_id,deskripsi,harga_beli,harga_jual,stok,stok_minimum,satuan) VALUES (?,?,?,?,?,?,?,?,?)");
    $katId = $kategori_id === 'NULL' ? null : $kategori_id;
    $stmt->bind_param("ssissdiis", $kode,$nama,$katId,$deskripsi,$harga_beli,$harga_jual,$stok,$stok_minimum,$satuan);
    if ($stmt->execute()) {
        setFlash('success', 'Produk berhasil ditambahkan!');
        header('Location: index.php'); exit;
    } else {
        $error = 'Gagal menambah produk: ' . $stmt->error;
    }
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-plus-circle me-2"></i>Tambah Produk</h1>
        <p>Tambahkan produk baru ke inventaris</p>
    </div>
    <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div>

<?php if(isset($error)): ?>
<div class="alert" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);color:#fca5a5;border-radius:12px;padding:14px;margin-bottom:16px;">
    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
</div>
<?php endif; ?>

<div class="card-glass">
    <div class="card-body">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label-glass">Kode Produk *</label>
                    <input type="text" name="kode" class="form-control form-control-glass" required value="<?= htmlspecialchars($_POST['kode'] ?? 'ATK-'.str_pad(rand(1,999),3,'0',STR_PAD_LEFT)) ?>">
                </div>
                <div class="col-md-8">
                    <label class="form-label-glass">Nama Produk *</label>
                    <input type="text" name="nama" class="form-control form-control-glass" required value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Kategori</label>
                    <select name="kategori_id" class="form-select form-select-glass">
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= ($_POST['kategori_id'] ?? '')==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['nama_kategori']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Satuan</label>
                    <select name="satuan" class="form-select form-select-glass">
                        <?php foreach(['pcs','rim','pak','lusin','box','botol','set'] as $s): ?>
                        <option value="<?= $s ?>" <?= ($_POST['satuan'] ?? 'pcs')==$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Harga Beli (Rp) *</label>
                    <input type="number" name="harga_beli" class="form-control form-control-glass" required min="0" value="<?= $_POST['harga_beli'] ?? '' ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Harga Jual (Rp) *</label>
                    <input type="number" name="harga_jual" class="form-control form-control-glass" required min="0" value="<?= $_POST['harga_jual'] ?? '' ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Stok Awal</label>
                    <input type="number" name="stok" class="form-control form-control-glass" min="0" value="<?= $_POST['stok'] ?? 0 ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Stok Minimum</label>
                    <input type="number" name="stok_minimum" class="form-control form-control-glass" min="0" value="<?= $_POST['stok_minimum'] ?? 5 ?>">
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control form-control-glass" rows="3"><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary-glass"><i class="bi bi-save me-2"></i>Simpan Produk</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
