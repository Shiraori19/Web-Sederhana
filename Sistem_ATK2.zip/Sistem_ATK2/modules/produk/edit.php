<?php
$pageTitle = 'Edit Produk';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

$id = (int)($_GET['id'] ?? 0);
$produk = $conn->query("SELECT * FROM produk WHERE id=$id AND is_active=1")->fetch_assoc();
if (!$produk) { header('Location: index.php'); exit; }

$categories = [];
$r = $conn->query("SELECT * FROM kategori ORDER BY nama_kategori");
if ($r) while($row = $r->fetch_assoc()) $categories[] = $row;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = sanitize($conn, $_POST['nama']);
    $kategori_id = (int)$_POST['kategori_id'] ?: null;
    $deskripsi = sanitize($conn, $_POST['deskripsi']);
    $harga_beli = (float)$_POST['harga_beli'];
    $harga_jual = (float)$_POST['harga_jual'];
    $stok_minimum = (int)$_POST['stok_minimum'];
    $satuan = sanitize($conn, $_POST['satuan']);

    $stmt = $conn->prepare("UPDATE produk SET nama=?,kategori_id=?,deskripsi=?,harga_beli=?,harga_jual=?,stok_minimum=?,satuan=? WHERE id=?");
    $stmt->bind_param("sissdiisi",$nama,$kategori_id,$deskripsi,$harga_beli,$harga_jual,$stok_minimum,$satuan,$id);
    // Fix: bind correct number of params
    if ($conn->query("UPDATE produk SET nama='".sanitize($conn,$nama)."', kategori_id=".($kategori_id?:0).", deskripsi='".sanitize($conn,$deskripsi)."', harga_beli=$harga_beli, harga_jual=$harga_jual, stok_minimum=$stok_minimum, satuan='".sanitize($conn,$satuan)."' WHERE id=$id")) {
        setFlash('success', 'Produk berhasil diperbarui!');
        header('Location: index.php'); exit;
    }
}

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-pencil me-2"></i>Edit Produk</h1>
        <p>Edit data produk: <?= htmlspecialchars($produk['nama']) ?></p>
    </div>
    <a href="index.php" class="btn btn-outline-glass"><i class="bi bi-arrow-left me-2"></i>Kembali</a>
</div>

<div class="card-glass">
    <div class="card-body">
        <form method="POST">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label-glass">Kode Produk</label>
                    <input type="text" class="form-control form-control-glass" value="<?= $produk['kode'] ?>" disabled>
                </div>
                <div class="col-md-8">
                    <label class="form-label-glass">Nama Produk *</label>
                    <input type="text" name="nama" class="form-control form-control-glass" required value="<?= htmlspecialchars($produk['nama']) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Kategori</label>
                    <select name="kategori_id" class="form-select form-select-glass">
                        <option value="">-- Pilih --</option>
                        <?php foreach($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $produk['kategori_id']==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['nama_kategori']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label-glass">Satuan</label>
                    <select name="satuan" class="form-select form-select-glass">
                        <?php foreach(['pcs','rim','pak','lusin','box','botol','set'] as $s): ?>
                        <option value="<?= $s ?>" <?= $produk['satuan']==$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label-glass">Harga Beli (Rp)</label>
                    <input type="number" name="harga_beli" class="form-control form-control-glass" min="0" value="<?= $produk['harga_beli'] ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label-glass">Harga Jual (Rp)</label>
                    <input type="number" name="harga_jual" class="form-control form-control-glass" min="0" value="<?= $produk['harga_jual'] ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label-glass">Stok Minimum</label>
                    <input type="number" name="stok_minimum" class="form-control form-control-glass" min="0" value="<?= $produk['stok_minimum'] ?>">
                </div>
                <div class="col-12">
                    <label class="form-label-glass">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control form-control-glass" rows="3"><?= htmlspecialchars($produk['deskripsi'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <div class="d-flex align-items-center gap-3" style="padding:16px;background:rgba(99,102,241,0.06);border-radius:12px;">
                        <div><span class="form-label-glass mb-0">Stok Saat Ini:</span></div>
                        <div><strong style="font-size:20px; color:<?= $produk['stok']<=$produk['stok_minimum']?'var(--danger)':'var(--success)' ?>"><?= $produk['stok'] ?> <?= $produk['satuan'] ?></strong></div>
                        <small style="color:var(--text-muted)">Gunakan modul Stok untuk menambah/mengurangi stok</small>
                    </div>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary-glass"><i class="bi bi-save me-2"></i>Update Produk</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
