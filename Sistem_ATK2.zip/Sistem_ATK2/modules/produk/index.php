<?php
$pageTitle = 'Manajemen Produk';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin','gudang']);

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("UPDATE produk SET is_active=0 WHERE id=$id");
    setFlash('success', 'Produk berhasil dihapus.');
    header('Location: index.php'); exit;
}

// Fetch products
$search = sanitize($conn, $_GET['search'] ?? '');
$where = "WHERE p.is_active=1";
if ($search) $where .= " AND (p.nama LIKE '%$search%' OR p.kode LIKE '%$search%')";
$products = [];
$r = $conn->query("SELECT p.*, k.nama_kategori FROM produk p LEFT JOIN kategori k ON p.kategori_id=k.id $where ORDER BY p.id DESC");
if ($r) while($row = $r->fetch_assoc()) $products[] = $row;

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';
?>

<div class="page-header">
    <div>
        <h1><i class="bi bi-box-seam me-2"></i>Produk</h1>
        <p>Kelola semua produk toko ATK Anda</p>
    </div>
    <a href="tambah.php" class="btn btn-primary-glass"><i class="bi bi-plus-lg me-2"></i>Tambah Produk</a>
</div>

<!-- Search -->
<div class="card-glass mb-4">
    <div class="card-body py-3">
        <form method="GET" class="d-flex gap-2">
            <input type="text" name="search" class="form-control-glass flex-grow-1" placeholder="Cari produk (nama/kode)..." value="<?= htmlspecialchars($search) ?>">
            <button class="btn btn-primary-glass"><i class="bi bi-search"></i></button>
            <?php if($search): ?><a href="index.php" class="btn btn-outline-glass">Reset</a><?php endif; ?>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card-glass">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead>
                    <tr>
                        <th>Kode</th><th>Nama Produk</th><th>Kategori</th>
                        <th>Harga Beli</th><th>Harga Jual</th><th>Stok</th><th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($products as $p): ?>
                <tr>
                    <td><code style="color:var(--accent)"><?= $p['kode'] ?></code></td>
                    <td><strong><?= htmlspecialchars($p['nama']) ?></strong></td>
                    <td><span class="badge-status badge-primary"><?= htmlspecialchars($p['nama_kategori'] ?? '-') ?></span></td>
                    <td><?= formatRupiah($p['harga_beli']) ?></td>
                    <td><?= formatRupiah($p['harga_jual']) ?></td>
                    <td>
                        <span class="badge-status <?= $p['stok']<=$p['stok_minimum']?'badge-danger':'badge-success' ?>">
                            <?= $p['stok'] ?> <?= $p['satuan'] ?>
                        </span>
                    </td>
                    <td>
                        <div class="d-flex gap-1">
                            <a href="edit.php?id=<?= $p['id'] ?>" class="btn-sm-icon" title="Edit"><i class="bi bi-pencil"></i></a>
                            <a href="index.php?delete=<?= $p['id'] ?>" class="btn-sm-icon danger" title="Hapus" onclick="return confirm('Hapus produk ini?')"><i class="bi bi-trash"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($products)): ?>
                <tr><td colspan="7" class="empty-state-dash">Tidak ada produk ditemukan</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
