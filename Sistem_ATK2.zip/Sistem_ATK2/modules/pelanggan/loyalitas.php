<?php
$pageTitle = 'Program Loyalitas';
require_once __DIR__ . '/../../includes/auth_check.php';
requireRole(['admin']);

$customers = [];
$r = $conn->query("SELECT * FROM pelanggan ORDER BY poin_loyalitas DESC");
if ($r) while($row = $r->fetch_assoc()) $customers[] = $row;

$totalPoin = array_sum(array_column($customers, 'poin_loyalitas'));
$levelCounts = ['Bronze'=>0,'Silver'=>0,'Gold'=>0,'Platinum'=>0];
foreach($customers as $c) $levelCounts[$c['level']]++;

include __DIR__ . '/../../includes/header.php';
include __DIR__ . '/../../includes/sidebar.php';

$levelConfig = [
    'Bronze'=>['color'=>'#94a3b8','min'=>0,'icon'=>'bi-award'],
    'Silver'=>['color'=>'#06b6d4','min'=>1000000,'icon'=>'bi-award-fill'],
    'Gold'=>['color'=>'#f59e0b','min'=>5000000,'icon'=>'bi-trophy'],
    'Platinum'=>['color'=>'#8b5cf6','min'=>10000000,'icon'=>'bi-gem'],
];
?>

<div class="page-header">
    <div><h1><i class="bi bi-heart me-2"></i>Program Loyalitas</h1><p>Kelola program loyalitas dan reward pelanggan</p></div>
</div>

<div class="row g-3 mb-4">
    <?php foreach($levelConfig as $lvl => $cfg): ?>
    <div class="col-xl-3 col-md-6">
        <div class="kpi-card">
            <div class="kpi-icon" style="background:<?= $cfg['color'] ?>22;color:<?= $cfg['color'] ?>"><i class="bi <?= $cfg['icon'] ?>"></i></div>
            <div class="kpi-value" style="color:<?= $cfg['color'] ?>"><?= $levelCounts[$lvl] ?></div>
            <div class="kpi-label"><?= $lvl ?> Members</div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Level Guide -->
<div class="card-glass mb-4">
    <div class="card-header"><i class="bi bi-info-circle me-2"></i>Sistem Level & Poin</div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <h6 style="color:var(--text-bright);margin-bottom:12px">Cara Mengumpulkan Poin</h6>
                <ul style="color:var(--text-muted);font-size:13px;padding-left:20px">
                    <li>Setiap pembelian Rp 10.000 = <strong style="color:var(--warning)">1 Poin</strong></li>
                    <li>Poin hanya berlaku untuk <strong style="color:var(--accent)">pembayaran digital</strong> (QRIS, E-Wallet, Transfer)</li>
                    <li>Pembayaran cash <strong>tidak</strong> mendapatkan poin</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6 style="color:var(--text-bright);margin-bottom:12px">Level Keanggotaan</h6>
                <div style="font-size:13px">
                    <?php foreach($levelConfig as $lvl => $cfg): ?>
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <i class="bi <?= $cfg['icon'] ?>" style="color:<?= $cfg['color'] ?>;font-size:18px"></i>
                        <strong style="color:<?= $cfg['color'] ?>"><?= $lvl ?></strong>
                        <span style="color:var(--text-muted)">— Total belanja ≥ <?= formatRupiah($cfg['min']) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Leaderboard -->
<div class="card-glass">
    <div class="card-header"><i class="bi bi-trophy me-2"></i>Leaderboard Pelanggan</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table-glass">
                <thead><tr><th>#</th><th>Pelanggan</th><th>Level</th><th>Poin</th><th>Total Belanja</th><th>Progress</th></tr></thead>
                <tbody>
                <?php foreach($customers as $i => $c):
                    $nextLevel = 'Bronze'; $nextMin = 1000000;
                    if ($c['total_belanja'] >= 10000000) { $nextLevel = 'MAX'; $pct = 100; }
                    elseif ($c['total_belanja'] >= 5000000) { $nextMin = 10000000; $pct = ($c['total_belanja']/10000000)*100; }
                    elseif ($c['total_belanja'] >= 1000000) { $nextMin = 5000000; $pct = ($c['total_belanja']/5000000)*100; }
                    else { $nextMin = 1000000; $pct = ($c['total_belanja']/1000000)*100; }
                    $lvlCfg = $levelConfig[$c['level']];
                ?>
                <tr>
                    <td><strong style="color:var(--text-muted)"><?= $i+1 ?></strong></td>
                    <td><strong><?= htmlspecialchars($c['nama']) ?></strong></td>
                    <td><span style="color:<?= $lvlCfg['color'] ?>;font-weight:600"><i class="bi <?= $lvlCfg['icon'] ?> me-1"></i><?= $c['level'] ?></span></td>
                    <td><strong style="color:var(--warning)"><?= number_format($c['poin_loyalitas']) ?></strong></td>
                    <td><?= formatRupiah($c['total_belanja']) ?></td>
                    <td style="min-width:120px">
                        <div style="width:100%;height:6px;background:var(--dark-3);border-radius:3px;overflow:hidden">
                            <div style="width:<?= min($pct,100) ?>%;height:100%;background:<?= $lvlCfg['color'] ?>;border-radius:3px;transition:width 0.5s"></div>
                        </div>
                        <small style="color:var(--text-muted);font-size:10px"><?= $nextLevel=='MAX'?'Level Maksimal':formatRupiah($nextMin) ?></small>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
