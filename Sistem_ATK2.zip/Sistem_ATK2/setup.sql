-- ============================================
-- Sistem Informasi Toko Alat Tulis Kantor v2
-- Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS `sistem_atk2` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sistem_atk2`;

-- ============================================
-- Tabel Users (Autentikasi & Role)
-- ============================================
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('admin','kasir','gudang') NOT NULL DEFAULT 'kasir',
    `avatar` VARCHAR(255) DEFAULT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `last_login` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- Tabel Kategori Produk
-- ============================================
CREATE TABLE IF NOT EXISTS `kategori` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama_kategori` VARCHAR(100) NOT NULL,
    `deskripsi` TEXT DEFAULT NULL,
    `icon` VARCHAR(50) DEFAULT 'bi-tag',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- Tabel Produk
-- ============================================
CREATE TABLE IF NOT EXISTS `produk` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `kode` VARCHAR(20) NOT NULL UNIQUE,
    `nama` VARCHAR(200) NOT NULL,
    `kategori_id` INT DEFAULT NULL,
    `deskripsi` TEXT DEFAULT NULL,
    `harga_beli` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `harga_jual` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `stok` INT NOT NULL DEFAULT 0,
    `stok_minimum` INT NOT NULL DEFAULT 5,
    `satuan` VARCHAR(20) DEFAULT 'pcs',
    `gambar` VARCHAR(255) DEFAULT NULL,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`kategori_id`) REFERENCES `kategori`(`id`) ON DELETE SET NULL,
    INDEX `idx_produk_kategori` (`kategori_id`),
    INDEX `idx_produk_stok` (`stok`, `stok_minimum`)
) ENGINE=InnoDB;

-- ============================================
-- Tabel Supplier
-- ============================================
CREATE TABLE IF NOT EXISTS `supplier` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(150) NOT NULL,
    `kontak` VARCHAR(20) DEFAULT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `alamat` TEXT DEFAULT NULL,
    `kota` VARCHAR(100) DEFAULT NULL,
    `status` ENUM('aktif','nonaktif') DEFAULT 'aktif',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- Tabel Pelanggan
-- ============================================
CREATE TABLE IF NOT EXISTS `pelanggan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nama` VARCHAR(150) NOT NULL,
    `telepon` VARCHAR(20) DEFAULT NULL,
    `email` VARCHAR(100) DEFAULT NULL,
    `alamat` TEXT DEFAULT NULL,
    `poin_loyalitas` INT DEFAULT 0,
    `level` ENUM('Bronze','Silver','Gold','Platinum') DEFAULT 'Bronze',
    `total_belanja` DECIMAL(15,2) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- Tabel Stok Masuk
-- ============================================
CREATE TABLE IF NOT EXISTS `stok_masuk` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `produk_id` INT NOT NULL,
    `supplier_id` INT DEFAULT NULL,
    `jumlah` INT NOT NULL,
    `harga_beli` DECIMAL(12,2) DEFAULT 0,
    `tanggal` DATE NOT NULL,
    `keterangan` TEXT DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`produk_id`) REFERENCES `produk`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`supplier_id`) REFERENCES `supplier`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_stok_masuk_tanggal` (`tanggal`)
) ENGINE=InnoDB;

-- ============================================
-- Tabel Stok Keluar
-- ============================================
CREATE TABLE IF NOT EXISTS `stok_keluar` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `produk_id` INT NOT NULL,
    `jumlah` INT NOT NULL,
    `tanggal` DATE NOT NULL,
    `tipe` ENUM('penjualan','adjustment','retur','rusak') DEFAULT 'penjualan',
    `keterangan` TEXT DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`produk_id`) REFERENCES `produk`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- Tabel Penjualan (Header)
-- ============================================
CREATE TABLE IF NOT EXISTS `penjualan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `no_invoice` VARCHAR(30) NOT NULL UNIQUE,
    `pelanggan_id` INT DEFAULT NULL,
    `total` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `diskon` DECIMAL(15,2) DEFAULT 0,
    `pajak` DECIMAL(15,2) DEFAULT 0,
    `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0,
    `bayar` DECIMAL(15,2) DEFAULT 0,
    `kembalian` DECIMAL(15,2) DEFAULT 0,
    `metode_bayar` ENUM('cash','qris','ewallet','transfer') DEFAULT 'cash',
    `channel` ENUM('toko','shopee','tokopedia','website','lainnya') DEFAULT 'toko',
    `status` ENUM('selesai','pending','batal') DEFAULT 'selesai',
    `catatan` TEXT DEFAULT NULL,
    `tanggal` DATETIME NOT NULL,
    `user_id` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_penjualan_tanggal` (`tanggal`),
    INDEX `idx_penjualan_channel` (`channel`)
) ENGINE=InnoDB;

-- ============================================
-- Tabel Detail Penjualan
-- ============================================
CREATE TABLE IF NOT EXISTS `detail_penjualan` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `penjualan_id` INT NOT NULL,
    `produk_id` INT NOT NULL,
    `jumlah` INT NOT NULL,
    `harga` DECIMAL(12,2) NOT NULL,
    `subtotal` DECIMAL(15,2) NOT NULL,
    FOREIGN KEY (`penjualan_id`) REFERENCES `penjualan`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`produk_id`) REFERENCES `produk`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- Tabel Purchase Order (Header)
-- ============================================
CREATE TABLE IF NOT EXISTS `purchase_order` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `no_po` VARCHAR(30) NOT NULL UNIQUE,
    `supplier_id` INT NOT NULL,
    `total` DECIMAL(15,2) DEFAULT 0,
    `status` ENUM('draft','dikirim','diterima','dibatalkan') DEFAULT 'draft',
    `catatan` TEXT DEFAULT NULL,
    `tanggal` DATE NOT NULL,
    `tanggal_diterima` DATE DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`supplier_id`) REFERENCES `supplier`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
    INDEX `idx_po_status` (`status`)
) ENGINE=InnoDB;

-- ============================================
-- Tabel Detail Purchase Order
-- ============================================
CREATE TABLE IF NOT EXISTS `detail_po` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `po_id` INT NOT NULL,
    `produk_id` INT NOT NULL,
    `jumlah` INT NOT NULL,
    `harga` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (`po_id`) REFERENCES `purchase_order`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`produk_id`) REFERENCES `produk`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- Tabel Marketplace Orders
-- ============================================
CREATE TABLE IF NOT EXISTS `marketplace_orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `platform` ENUM('shopee','tokopedia','website','lainnya') NOT NULL,
    `order_id_external` VARCHAR(100) DEFAULT NULL,
    `penjualan_id` INT DEFAULT NULL,
    `nama_pembeli` VARCHAR(150) DEFAULT NULL,
    `alamat_pengiriman` TEXT DEFAULT NULL,
    `status_pengiriman` ENUM('pending','diproses','dikirim','selesai','batal') DEFAULT 'pending',
    `no_resi` VARCHAR(100) DEFAULT NULL,
    `kurir` VARCHAR(50) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`penjualan_id`) REFERENCES `penjualan`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- Index tambahan untuk performa
-- ============================================
